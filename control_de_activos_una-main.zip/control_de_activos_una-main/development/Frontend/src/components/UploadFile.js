export default function UploadFile() {

    return (
        <div className="container">
<header id="header" className="header fixed-top d-flex align-items-center">
        <a href="index.php">
          <img
            src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png"
            alt=""
          />
        </a>

        <div className="d-flex align-items-center justify-content-between">
          <i className="bi bi-list toggle-sidebar-btn"></i>
        </div>

        <nav className="header-nav ms-auto">
          <ul className="d-flex align-items-center">
            <li className="nav-item d-block d-lg-none">
              <a className="nav-link nav-icon search-bar-toggle " href="#">
                <i className="bi bi-search"></i>
              </a>
            </li>
            {/* <!-- End Search Icon--> */}

            <li className="nav-item dropdown">
              <a className="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                <i className="bi bi-bell"></i>
                <span className="badge bg-primary badge-number">4</span>
              </a>
              {/* <!-- End Notification Icon --> */}

              <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                <li className="dropdown-header">
                  Tienes 4 nuevas notificaciones
                  <a href="#">
                    <span className="badge rounded-pill bg-primary p-2 ms-2">
                      Ver todas
                    </span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-exclamation-circle text-warning"></i>
                  <div>
                    <h4>Lorem Ipsum</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>30 min. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-x-circle text-danger"></i>
                  <div>
                    <h4>Atque rerum nesciunt</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>1 hr. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>
                    <h4>Sit rerum fuga</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>2 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-info-circle text-primary"></i>
                  <div>
                    <h4>Dicta reprehenderit</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>4 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>
                <li className="dropdown-footer">
                  <a href="#">Mostrar todas las notificaciones</a>
                </li>
              </ul>
              {/* <!-- End Notification Dropdown Items --> */}
            </li>
            {/* <!-- End Notification Nav --> */}

            <li className="nav-item dropdown pe-3">
              <a
                className="nav-link nav-profile d-flex align-items-center pe-0"
                href="#"
                data-bs-toggle="dropdown"
              >
                <img
                  src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460__340.png" 
                  alt=""
                  className="rounded-circle"
                />
                <span className="d-none d-md-block dropdown-toggle ps-2">
                  Allan M
                </span>
              </a>
              {/* <!-- End Profile Iamge Icon --> */}

              <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                <li className="dropdown-header">
                  <h6>Allan</h6>
                  <span>Funcionario</span>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i className="bi bi-person"></i>
                    <span>Mi Perfil</span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i className="bi bi-gear"></i>
                    <span>Configuracion de la Cuenta</span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                {/* <!-- <li>
          <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
            <i class="bi bi-question-circle"></i>
            <span>Need Help?</span>
          </a>
        </li>
        <li>
          <hr class="dropdown-divider">
        </li> --> */}

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="pages-login.php"
                  >
                    <i className="bi bi-box-arrow-right"></i>
                    <span>Cerrar Sesion</span>
                  </a>
                </li>
              </ul>
              {/* <!-- End Profile Dropdown Items --> */}
            </li>
            {/* <!-- End Profile Nav --> */}
          </ul>
        </nav>
        {/* <!-- End Icons Navigation --> */}
      </header>
      {/* <!-- End Header --> */}

      {/* <!-- ======= Sidebar ======= --> */}
  <aside id="sidebar" className="sidebar">

    <ul className="sidebar-nav" id="sidebar-nav">

      <li className="nav-item">
        <a className="nav-link " href="index.php">
          <i className="bi bi-house-door-fillbi bi-house-door-fill"></i>
          <span>Inicio</span>
        </a>
      </li>
      {/* <!-- End Dashboard Nav --> */}

      <li className="nav-item">
        <a className="nav-link collapsed" href="activos.php">
          <i className="bi bi-filter-square-fill"></i>
          <span>Filtro Activos</span>
        </a>
      </li>
      {/* <!-- End Dashboard Nav --> */}

      {/* <!-- <li class="nav-heading">Pages</li> --> */}

      

      <li className="nav-item">
        <a className="nav-link collapsed" href="subir.php">
          <i className="bi bi-cloud-upload-fill"></i>
          <span>Subir</span>
        </a>
      </li>
      {/* <!-- End F.A.Q Page Nav --> */}

      

      

      {/* <!-- <span>
        <img height="100%" width="90%" src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png" align="left">
      </span> --> */}


    </ul>

  </aside>
  {/* <!-- End Sidebar--> */}
<main id="main" class="main">


    
<section class="section dashboard">
  

  <div class="card">
    <div class="card-header">
    {/* <!-- <img src="https://img.youtube.com/vi/ku7t9gezlpg/maxresdefault.jpg" alt="logo_una" class="bg-image"> --> */}
    <h5 class="card-title">Subir archivos</h5>
        <div class="card-body">
            
            <form action="subir.php" method="post" class="form-control" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-lg-10">
                      <input class="form-control" type="file" name="archivo" id="txt_archivo" accept=".csv,.xlsx,.xls" />
                  </div>
                  <div class="col-lg-2">
                       <input type="submit" class="btn btn-danger" value="Subir Archivo" name="enviar" onclick="mostrar()"/>
                  </div>     
                        
                </div>  
            </form>
        </div>
        {/* <script type="text/javascript">
          
          function mostrar(){

            alert("Archivo subido correctamente");
            swal({
              title: "Seguro que desea continuar?",
              
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((willUpload) => {
              if (willUpload) {
                swal("Su archivo se subió exitosamente!", {
                  icon: "success",
                });
                <?php
                  require 'vendor/autoload.php';
                  require 'data.php';
                  
                  //lectura
                  use PhpOffice\PhpSpreadsheet\IOFactory;
                  use PhpOffice\PhpSpreadsheet\Cell\Coordinate;//getCellByColumnAndRow(1,$indiceFila)->getCellByColumnAndRow('A',$indiceFila)
                  
                  if(isset($_POST["enviar"])){

                  $archivo = $_FILES['archivo']['name'];//nombre del archivo que se sube al servidor 
                  $documento = IOFactory::load($archivo);//cargar el archivo, para poder leerlo
                  $totalHojas = $documento->getSheetCount();//para obtener el numero de hojas que tiene el excel
                  
                  
                      $hojaActual = $documento->getSheet(0);
                      $numeroFilas = $hojaActual->getHighestDataRow();//obtener numero de filas
                      $letra = $hojaActual->getHighestColumn();//trae la columna mas alta que haya en el archivo que seria en este caso J
                  
                      $numeroLetra = Coordinate::columnIndexFromString($letra);//10=J en el excel
                      
                      for ($indiceFila = 2; $indiceFila < $numeroFilas; $indiceFila++) { //el arreglo que recorre todas las filas de nuestra hoja de excel
                  
                  
                              $valorA = $hojaActual->getCellByColumnAndRow(1,$indiceFila);
                              $valorB = $hojaActual->getCellByColumnAndRow(2,$indiceFila);
                              $valorC = $hojaActual->getCellByColumnAndRow(3,$indiceFila);
                              $valorD = $hojaActual->getCellByColumnAndRow(4,$indiceFila);
                              $valorE = $hojaActual->getCellByColumnAndRow(5,$indiceFila);
                              $valorF = $hojaActual->getCellByColumnAndRow(6,$indiceFila);
                              $valorG = $hojaActual->getCellByColumnAndRow(7,$indiceFila);
                              $valorH = $hojaActual->getCellByColumnAndRow(8,$indiceFila);
                              $valorI = $hojaActual->getCellByColumnAndRow(9,$indiceFila);
                              $valorJ = $hojaActual->getCellByColumnAndRow(10,$indiceFila);
                  
                              $sql = "INSERT INTO sigesa (numeroetiqueta,descripcion,marca,modelo,serie,valorlibros,condicion,claseactivo,idfuncionario,nombrefuncionario) VALUES 
                              ('$valorA','$valorB','$valorC','$valorD','$valorE','$valorF','$valorG',
                              '$valorH','$valorI','$valorJ')";
                              $mysqli->query($sql);

                      }
                      echo "Datos insertados correctamente <br>";
                  }
                    
                ?>
              } else {
                swal("Su archivo no se subió!");
              }
            });
            
          }
        </script> */}
        
    
</div>
  </div>
  

</section>

</main>{/* <!-- End #main --> */}
{/* <!-- ======= Footer ======= --> */}
<footer id="footer" className="footer">
    <div className="credits">
      © 2022 
    | Universidad Nacional Campus Sarapiquí, Costa Rica.
    </div>
  </footer>
  {/* <!-- End Footer --> */}
        </div>    
    );
}