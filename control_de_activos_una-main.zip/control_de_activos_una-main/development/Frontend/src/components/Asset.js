export default function Asset() {
  return (
    <div className="container">
      {/* <!-- ======= Header ======= --> */}
      <header id="header" class="header fixed-top d-flex align-items-center">
        <a href="index.php">
          <img
            src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png"
            alt=""
          />
        </a>

        <div class="d-flex align-items-center justify-content-between">
          <i class="bi bi-list toggle-sidebar-btn"></i>
        </div>

        <nav class="header-nav ms-auto">
          <ul class="d-flex align-items-center">
            
            <li class="nav-item dropdown">
              <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                <i class="bi bi-bell"></i>
                <span class="badge bg-primary badge-number">4</span>
              </a>
              {/* <!-- End Notification Icon --> */}

              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                <li class="dropdown-header">
                  Tienes 4 nofiticaciones nuevas
                  <a href="#">
                    <span class="badge rounded-pill bg-primary p-2 ms-2">
                      Ver todas
                    </span>
                  </a>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li class="notification-item">
                  <i class="bi bi-exclamation-circle text-warning"></i>
                  <div>
                    <h4>Lorem Ipsum</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>30 min. ago</p>
                  </div>
                </li>

                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li class="notification-item">
                  <i class="bi bi-x-circle text-danger"></i>
                  <div>
                    <h4>Atque rerum nesciunt</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>1 hr. ago</p>
                  </div>
                </li>

                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li class="notification-item">
                  <i class="bi bi-check-circle text-success"></i>
                  <div>
                    <h4>Sit rerum fuga</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>2 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li class="notification-item">
                  <i class="bi bi-info-circle text-primary"></i>
                  <div>
                    <h4>Dicta reprehenderit</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>4 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr class="dropdown-divider" />
                </li>
                <li class="dropdown-footer">
                  <a href="#">Mostrar todas las notificaciones</a>
                </li>
              </ul>
              {/* <!-- End Notification Dropdown Items --> */}
            </li>
            {/* <!-- End Notification Nav --> */}

            <li class="nav-item dropdown pe-3">
              <a
                class="nav-link nav-profile d-flex align-items-center pe-0"
                href="#"
                data-bs-toggle="dropdown"
              >
                <img
                  src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460__340.png"
                  alt=""
                  class="rounded-circle"
                />
                <span class="d-none d-md-block dropdown-toggle ps-2">
                  Allan M
                </span>
              </a>
              {/* <!-- End Profile Iamge Icon --> */}

              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                <li class="dropdown-header">
                  <h6>Allan</h6>
                  <span>Funcionario</span>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li>
                  <a
                    class="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i class="bi bi-person"></i>
                    <span>Mi Perfil</span>
                  </a>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li>
                  <a
                    class="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i class="bi bi-gear"></i>
                    <span>Configuracion de la Cuenta</span>
                  </a>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>

                <li>
                  <a
                    class="dropdown-item d-flex align-items-center"
                    href="pages-login.php"
                  >
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Cerrar Sesion</span>
                  </a>
                </li>
              </ul>
              {/* <!-- End Profile Dropdown Items --> */}
            </li>
            {/* <!-- End Profile Nav --> */}
          </ul>
        </nav>
        {/* <!-- End Icons Navigation --> */}
      </header>
      {/* <!-- End Header --> */}

      <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
          <li class="nav-item">
            <a class="nav-link " href="index.php">
              <i class="bi bi-house-door-fillbi bi-house-door-fill"></i>
              <span>Inicio</span>
            </a>
          </li>
          {/* <!-- End Dashboard Nav --> */}

          <li class="nav-item">
            <a class="nav-link collapsed" href="activos.php">
              <i class="bi bi-filter-square-fill"></i>
              <span>Filtro Activos</span>
            </a>
          </li>
          {/* <!-- End Dashboard Nav --> */}

          {/* <!-- <li class="nav-heading">Pages</li> --> */}

          <li class="nav-item">
            <a class="nav-link collapsed" href="subir.php">
              <i class="bi bi-cloud-upload-fill"></i>
              <span>Subir</span>
            </a>
          </li>
          {/* <!-- End F.A.Q Page Nav --> */}

          {/* <!-- <span>
        <img height="100%" width="90%" src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png" align="left">
      </span> --> */}
        </ul>
      </aside>
      {/* <!-- End Sidebar--> */}

      <main id="main" class="main">
        {/* <!-- End Page Title --> */}

        <section class="section dashboard">
          {/* <!-- <span>
        
          <img src="https://scontent.fsjo14-1.fna.fbcdn.net/v/t39.30808-6/271755805_4919547154780525_6867042417512969757_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=e3f864&_nc_ohc=mwP0BQTUzWsAX_nNlox&_nc_ht=scontent.fsjo14-1.fna&oh=00_AT8dIvvOaJTrpqBLCMT6GT1CmpjnMnhNTDHUqJkwD8YlnQ&oe=63444FA4" alt="" srcset=""/>
        
      </span> --> */}
          {/* <!-- INICIO TABLE --> */}
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Activos</h5>
              {/* <!-- Default Table -->
                    <table id="tablaSigesa" class="table table-striped table-bordered" style="width:100%">
                        <thead class="text-center">
                        <tr>
                            <th scope="col">Número de Etiqueta</th>
                            <th scope="col">Descripción</th>
                            <th scope="col">Marca</th>
                            <th scope="col">Modelo</th>
                            <th scope="col">Serie</th>
                            <th scope="col">Valor en Libros</th>
                            <th scope="col">Condición</th>
                            <th scope="col">Clase Activo</th>
                            <th scope="col">Identificación Funcionario</th>
                            <th scope="col">Nombre Funcionario</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            foreach($datos as $dato){
                        ?>
                        <tr>
                            <td><?php echo $dato['numeroetiqueta']?></td>
                            <td><?php echo $dato['descripcion']?></td>
                            <td><?php echo $dato['marca']?></td>
                            <td><?php echo $dato['modelo']?></td>
                            <td><?php echo $dato['serie']?></td>
                            <td><?php echo $dato['valorlibros']?></td>
                            <td><?php echo $dato['condicion']?></td>
                            <td><?php echo $dato['claseactivo']?></td>
                            <td><?php echo $dato['idfuncionario']?></td>
                            <td><?php echo $dato['nombrefuncionario']?></td>
                        </tr>
                        <?php
                            }
                        ?>
                        </tbody>
                    </table>
                    -- End Default Table Example -- */}
            </div>
          </div>
          // -- FIN TABLE -- // -- Optional JavaScript -- // -- jQuery first,
          then Popper.js, then Bootstrap JS --
          <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
          <script src="popper/popper.min.js"></script>
          <script src="bootstrap/js/bootstrap.min.js"></script>
          // -- datatables JS --
          <script
            type="text/javascript"
            src="datatables/datatables.min.js"
          ></script>
          // -- para usar botones en datatables JS --
          <script src="datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>
          <script src="datatables/JSZip-2.5.0/jszip.min.js"></script>
          <script src="datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
          <script src="datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
          <script src="datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
          // -- código JS propìo--
          <script type="text/javascript" src="main.js"></script>
          //-- Para los estilos en Excel --
          <script src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.1.1/js/buttons.html5.styles.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.1.1/js/buttons.html5.styles.templates.min.js"></script>
          {/* <script>
            $(document).ready(function(){
                $('#tablaSigesa').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.12.1/i18n/es-MX.json'
                        },       
            responsive: "true",        
            dom: 'Bfrtilp',       
        buttons:[ 
			{
				extend:    'excelHtml5',
				text:      '<i class="fas fa-file-excel"></i> ',
				titleAttr: 'Exportar a Excel',
				className: 'btn btn-success'
			},
			{
				extend:    'pdfHtml5',
				text:      '<i class="fas fa-file-pdf"></i> ',
				titleAttr: 'Exportar a PDF',
				className: 'btn btn-danger'
			},
			{
				extend:    'print',
				text:      '<i class="fa fa-print"></i> ',
				titleAttr: 'Imprimir',
				className: 'btn btn-info'
			},
		]            
        });
            });
        </script> */}
        </section>
      </main>
      {/* <!-- End #main --> */}

      {/* <!-- ======= Footer ======= --> */}
      <footer id="footer" class="footer">
        <div class="credits">
          © 2022 | Universidad Nacional Campus Sarapiquí, Costa Rica.
        </div>
      </footer>
      {/* <!-- End Footer --> */}

      {/* <!-- Vendor JS Files --> */}
      <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
      <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="assets/vendor/chart.js/chart.min.js"></script>
      <script src="assets/vendor/echarts/echarts.min.js"></script>
      <script src="assets/vendor/quill/quill.min.js"></script>
      <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
      <script src="assets/vendor/tinymce/tinymce.min.js"></script>
      <script src="assets/vendor/php-email-form/validate.js"></script>

      {/* <!-- Template Main JS File --> */}
      <script src="assets/js/main.js"></script>
    </div>
  );
}
