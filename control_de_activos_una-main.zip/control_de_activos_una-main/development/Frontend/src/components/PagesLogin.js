export function PagesLogin() {
  return (
    <div className="App">
      <main>
        <div className="container">
          <section className="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
                  <div className="card mb-3">
                    <div align="center">
                      <img
                        width="60%"
                        height="100%"
                        src="https://eis.una.ac.cr/authenticationendpoint/images/una-logo.png"
                        alt=""
                      />
                    </div>
                    <div className="pt-4 pb-2">
                      {/* <!-- style="background-color:#a31e32;" --> */}
                      <h5 className="card-title text-center pb-0 fs-4">
                        Inicia Sesión en tu Cuenta
                      </h5>
                    </div>
                    <div className="card-body">
                      <form className="row g-3 needs-validation" noValidate>
                        <div className="col-12">
                          <label htmlFor="yourId" className="form-label">
                            Cédula (ID)
                          </label>
                          <div className="input-group has-validation">
                            <input
                              type="text"
                              name="id"
                              className="form-control"
                              id="yourId"
                              required
                            />
                            <div className="invalid-feedback">
                              Por favor ingresar su cédula correctamente!
                            </div>
                          </div>
                        </div>

                        <div className="col-12">
                          <label htmlFor="yourPassword" className="form-label">
                            Constraseña
                          </label>
                          <input
                            type="password"
                            name="password"
                            className="form-control"
                            id="yourPassword"
                            required
                          />
                          <div className="invalid-feedback">
                            Por favor ingresar correctamente su constraseña!
                          </div>
                        </div>

                        <div className="col-12">
                          <div className="form-check">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              name="remember"
                              value="true"
                              id="rememberMe"
                            />
                            <label className="form-check-label" htmlFor="rememberMe">
                              Recuerdame
                            </label>
                          </div>
                        </div>
                        <div className="col-12">
                          <button className="btn btn-primary w-100" type="submit">
                            Iniciar Sesión
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
      {/* <!-- End #main --> */}

      {/* <!-- ======= Footer ======= --> */}
      <footer id="footer" className="footer">
        <div className="credits">
          © 2023 | Universidad Nacional Campus Sarapiquí, Costa Rica.
        </div>
      </footer>
      {/* <!-- End Footer --> */}
    </div>
  );
}
