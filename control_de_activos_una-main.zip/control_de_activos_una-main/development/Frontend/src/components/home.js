

export default function Home() {
    return (
      <div className="container">

      <header id="header" className="header fixed-top d-flex align-items-center">
        <a href="index.php">
          <img
            src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png"
            alt=""
          />
        </a>

        <div className="d-flex align-items-center justify-content-between">
          <i className="bi bi-list toggle-sidebar-btn"></i>
        </div>

        <nav className="header-nav ms-auto">
          <ul className="d-flex align-items-center">
            <li className="nav-item d-block d-lg-none">
              <a className="nav-link nav-icon search-bar-toggle " href="#">
                <i className="bi bi-search"></i>
              </a>
            </li>
            {/* <!-- End Search Icon--> */}

            <li className="nav-item dropdown">
              <a className="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                <i className="bi bi-bell"></i>
                <span className="badge bg-primary badge-number">4</span>
              </a>
              {/* <!-- End Notification Icon --> */}

              <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                <li className="dropdown-header">
                  Tienes 4 nuevas notificaciones
                  <a href="#">
                    <span className="badge rounded-pill bg-primary p-2 ms-2">
                      Ver todas
                    </span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-exclamation-circle text-warning"></i>
                  <div>
                    <h4>Lorem Ipsum</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>30 min. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-x-circle text-danger"></i>
                  <div>
                    <h4>Atque rerum nesciunt</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>1 hr. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-check-circle text-success"></i>
                  <div>
                    <h4>Sit rerum fuga</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>2 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li className="notification-item">
                  <i className="bi bi-info-circle text-primary"></i>
                  <div>
                    <h4>Dicta reprehenderit</h4>
                    <p>Quae dolorem earum veritatis oditseno</p>
                    <p>4 hrs. ago</p>
                  </div>
                </li>

                <li>
                  <hr className="dropdown-divider" />
                </li>
                <li className="dropdown-footer">
                  <a href="#">Mostrar todas las notificaciones</a>
                </li>
              </ul>
              {/* <!-- End Notification Dropdown Items --> */}
            </li>
            {/* <!-- End Notification Nav --> */}

            <li className="nav-item dropdown pe-3">
              <a
                className="nav-link nav-profile d-flex align-items-center pe-0"
                href="#"
                data-bs-toggle="dropdown"
              >
                <img
                  src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460__340.png" 
                  alt=""
                  className="rounded-circle"
                />
                <span className="d-none d-md-block dropdown-toggle ps-2">
                  Allan M
                </span>
              </a>
              {/* <!-- End Profile Iamge Icon --> */}

              <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                <li className="dropdown-header">
                  <h6>Allan</h6>
                  <span>Funcionario</span>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i className="bi bi-person"></i>
                    <span>Mi Perfil</span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="users-profile.php"
                  >
                    <i className="bi bi-gear"></i>
                    <span>Configuracion de la Cuenta</span>
                  </a>
                </li>
                <li>
                  <hr className="dropdown-divider" />
                </li>

                {/* <!-- <li>
          <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
            <i class="bi bi-question-circle"></i>
            <span>Need Help?</span>
          </a>
        </li>
        <li>
          <hr class="dropdown-divider">
        </li> --> */}

                <li>
                  <a
                    className="dropdown-item d-flex align-items-center"
                    href="pages-login.php"
                  >
                    <i className="bi bi-box-arrow-right"></i>
                    <span>Cerrar Sesion</span>
                  </a>
                </li>
              </ul>
              {/* <!-- End Profile Dropdown Items --> */}
            </li>
            {/* <!-- End Profile Nav --> */}
          </ul>
        </nav>
        {/* <!-- End Icons Navigation --> */}
      </header>
      {/* <!-- End Header --> */}

      {/* <!-- ======= Sidebar ======= --> */}
  <aside id="sidebar" className="sidebar">

    <ul className="sidebar-nav" id="sidebar-nav">

      <li className="nav-item">
        <a className="nav-link " href="index.php">
          <i className="bi bi-house-door-fillbi bi-house-door-fill"></i>
          <span>Inicio</span>
        </a>
      </li>
      {/* <!-- End Dashboard Nav --> */}

      <li className="nav-item">
        <a className="nav-link collapsed" href="activos.php">
          <i className="bi bi-filter-square-fill"></i>
          <span>Filtro Activos</span>
        </a>
      </li>
      {/* <!-- End Dashboard Nav --> */}

      {/* <!-- <li class="nav-heading">Pages</li> --> */}

      

      <li className="nav-item">
        <a className="nav-link collapsed" href="subir.php">
          <i className="bi bi-cloud-upload-fill"></i>
          <span>Subir</span>
        </a>
      </li>
      {/* <!-- End F.A.Q Page Nav --> */}

      

      

      {/* <!-- <span>
        <img height="100%" width="90%" src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png" align="left">
      </span> --> */}


    </ul>

  </aside>
  {/* <!-- End Sidebar--> */}
  
  {/* <div id="main" className="main"> */}
  <main id="main" className="main">
    
    <section className="section dashboard">
      
      <span className="span-logouna">
        <img src="https://img.youtube.com/vi/ku7t9gezlpg/maxresdefault.jpg" alt="logo_una" className="bg-image"   />
      </span>


    </section>

  </main>
  {/* </div> */}
  {/* <!-- End #main --> */}

  {/* <!-- ======= Footer ======= --> */}
  <footer id="footer" className="footer">
    <div className="credits">
      © 2022 
    | Universidad Nacional Campus Sarapiquí, Costa Rica.
    </div>
  </footer>
  {/* <!-- End Footer --> */}


    </div> 
    );
}