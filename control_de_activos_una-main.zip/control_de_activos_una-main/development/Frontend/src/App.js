//import logo from './logo.svg';
import './App.css';
import Asset from './components/Asset';
//import Home from './components/home';
import { PagesLogin } from './components/PagesLogin';
import UploadFile from './components/UploadFile';
//import { UsersProfile } from './components/Users-profile';

function App() {
  return (
    <PagesLogin/>
  );
}

export default App;
