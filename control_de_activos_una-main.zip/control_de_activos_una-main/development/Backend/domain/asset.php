<?php

class asset{


private $asset_Label_Number;
private $asset_Description;
private $asset_Brand;
private $asset_Model;
private $asset_Sire;
private $asset_ValuesBooks;
private $asset_Condition;
private $asset_Class;
private $id_Employee;
private $employee_Name;


function __construct($asset_Label_Number, $asset_Description, $asset_Brand, $asset_Model, $asset_Sire, $asset_ValuesBooks, $asset_Condition, $asset_Class, $id_Employee, $employee_Name){
$this->asset_Label_Number = $asset_Label_Number;
$this->asset_Description = $asset_Description;
$this->asset_Brand = $asset_Brand;
$this->asset_Model = $asset_Model;
$this->asset_Sire = $asset_Sire;
$this->asset_ValuesBooks = $asset_ValuesBooks;
$this->asset_Condition = $asset_Condition;
$this->asset_Class = $asset_Class;
$this->id_Employee = $id_Employee;
$this->employee_Name = $employee_Name;


}


function getAsset_Label_Number(){

return $this->asset_Label_Number;

}

function getAsset_Description(){

return $this->asset_Description;

}

function getAsset_Brand(){

return $this->asset_Brand;

}

function getAsset_Model(){

return $this->asset_Model;

}

function getAsset_Sire(){

return $this->asset_Sire;

}

function getAsset_ValuesBooks(){

return $this->asset_ValuesBooks;

}

function getAsset_Condition(){

return $this->asset_Condition;

}

function getAsset_Class(){

return $this->asset_Class;

}

function getId_Employee(){

return $this->id_Employee;

}

function getEmployee_Name(){

return $this->employee_Name;

}

//GET

//SET

function setAsset_Label_Number($asset_Label_Number){

$this->asset_Label_Number = $asset_Label_Number;

}

function setAsset_Description($asset_Description){

$this->asset_Description = $asset_Description;

}

function setAsset_Brand($asset_Brand){

$this->asset_Brand = $asset_Brand;

}

function setAsset_Model($asset_Model){

$this->asset_Model = $asset_Model;

}


function setAsset_Sire($asset_Sire){

$this->asset_Sire = $asset_Sire;

}

function setAsset_ValuesBooks($asset_ValuesBooks){

$this->asset_ValuesBooks = $asset_ValuesBooks;

}

function setAsset_Condition($asset_Condition){

$this->asset_Condition = $asset_Condition;

}

function setAsset_Class($asset_Class){

$this->asset_Class = $asset_Class;

}

function setId_Employee($id_Employee){

$this->id_Employee = $id_Employee;

}

function setEmployee_Name($employee_Name){  

$this->employee_Name = $employee_Name;

}




}








