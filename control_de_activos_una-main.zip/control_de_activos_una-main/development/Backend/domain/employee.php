<?php

class Employee{

    private $employee_Id;//id in database
    private $employee_Identification;// id in the company
    private $employee_Name;//name of the employee
    private $employee_LastName;// last name of the employee
    private $employee_Phone;// phone number of the employee
    private $employee_Email;// email of the employee
    private $employee_Password;// password of the employee
    private $employe_Active;// 1 is active, 0 is inactive
    private $employee_Photo;// 
    //active is a boolean, 1 is active, 0 is inactive
    public function __construct($employee_Id, $employee_Identification, $employee_Name, $employee_LastName,
     $employee_Phone, $employee_Email, $employee_Password, $employe_Active, $employee_Photo){
        //constructor
        $this->employee_Id = $employee_Id;//this is the id in the database 
        $this->employee_Identification = $employee_Identification;
        $this->employee_Name = $employee_Name;
        $this->employee_LastName = $employee_LastName;
        $this->employee_Phone = $employee_Phone;
        $this->employee_Email = $employee_Email;
        $this->employee_Password = $employee_Password;
        $this->employe_Active = $employe_Active;
        $this->employee_Photo = $employee_Photo;
    }

    //setters

    public function setEmployee_Id($employee_Id){
        $this->employee_Id = $employee_Id;//this is the id in the database 
    }

    public function setEmployee_Identification($employee_Identification){
        $this->employee_Identification = $employee_Identification;
    }

    public function setEmployee_Name($employee_Name){
        $this->employee_Name = $employee_Name;
    }

    public function setEmployee_LastName($employee_LastName){
        $this->employee_LastName = $employee_LastName;
    }

    public function setEmployee_Phone($employee_Phone){
        $this->employee_Phone = $employee_Phone;
    }
    
    public function setEmployee_Email($employee_Email){
        $this->employee_Email = $employee_Email;
    }

    public function setEmployee_Password($employee_Password){
        $this->employee_Password = $employee_Password;
    }

    public function setEmployee_Active($employe_Active){
        $this->employe_Active = $employe_Active;
    }

    public function setEmployee_Photo($employee_Photo) {
        $this->employee_Photo = $employee_Photo;
    }
    // end setters



    //getters
    public function getEmployee_Id(){
        return $this->employee_Id;
    }

    public function getEmployee_Identification(){
        return $this->employee_Identification;
    }

    public function getEmployee_Name(){
        return $this->employee_Name;
    }

    public function getEmployee_Lastname(){
        return $this->employee_LastName;
    }

    public function getEmployee_Phone(){
        return $this->employee_Phone;
    }

    public function getEmployee_Email(){
        return $this->employee_Email;
    }

    public function getEmployee_Password(){
        return $this->employee_Password;
    }

    public function getEmployee_Active(){
        return $this->employe_Active;
    }

    public function getEmployee_Photo() {
        return $this->employee_Photo;
    }

} 