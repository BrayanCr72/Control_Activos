<?php 

class User{

    private $id;
    private $correo;
    private $usuario;
    private $contrasenia;

    public function __construct($id,$correo,$usuario,$contrasenia)
    {
        $this->id = $id;
        $this->correo = $correo;
        $this->usuario = $usuario;
        $this->contrasenia = $contrasenia;
    }

    public function getId(){
        return $this->id;
    }

    public function getCorreo(){
        return $this->correo;
    }

    public function getUsuario(){
        return $this->usuario;
    }

    public function getContrasenia(){
        return $this->contrasenia;
    }

}