<?php
    session_start();
    // ! Se destruye la sesión
    session_destroy();
    // ! Se redirecciona a la página de inicio

    header("Location: ../view/login.php");

?>