
<!-- Modal -->
<div class="modal fade" id="newModal" tabindex="-1" aria-labelledby="newModal" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="newModal">Agregar Funcionario</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="employeeidentification">Cedula Funcionario</label>
                <input required type="text" name="employeeidentification" id="employeeidentification"/>

                <label for="employeename">Nombre Funcionario</label>
                <input required type="text" name="employeename" id="employeename"/>

                <label for="employeelastname">Apellidos Funcionario</label>
                <input required type="text" name="employeelastname" id="employeelastname"/>

                <label for="employeephone">Telefono Funcionario</label>
                <input required type="text" name="employeephone" id="employeephone"/>

                <label for="employeeemail">Correo Funcionario</label>
                <input required type="text" name="employeeemail" id="employeeemail"/>

                <label for="employeepassword">Contraseña Funcionario</label>
                <input required type="password" name="employeepassword" id="employeepassword"/>

                <label for="employeeactive">Activo</label>
                <input type="checkbox" id="employeeactive" name="employeeactive" >

            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
