// // Obtener el botón de la barra lateral
// const sidebarToggleButton = document.querySelector('#sidebar-toggle-btn');

// // Obtener el estado actual de la barra lateral del almacenamiento local
// const sidebarState = localStorage.getItem('sidebarState');

// // Si la barra lateral está abierta en el almacenamiento local, abrirla
// if (sidebarState === 'open') {
//   document.querySelector('.sidebar').setAttribute('data-state', 'open');
// }

// // Cuando se hace clic en el botón de la barra lateral
// sidebarToggleButton.addEventListener('click', function() {
//   // Cambiar el estado de la barra lateral
//   const sidebar = document.querySelector('.sidebar');
//   sidebar.getAttribute('data-state') === 'open' ? sidebar.setAttribute('data-state', 'closed') : sidebar.setAttribute('data-state', 'open');

//   // Guardar el estado actual en el almacenamiento local
//   const sidebarState = sidebar.getAttribute('data-state');
//   localStorage.setItem('sidebarState', sidebarState);
// });

// Obtener el botón de la barra lateral
const toggleSidebarButton = document.querySelector('.toggle-sidebar-btn');
// Obtener el elemento de la barra lateral
const sidebar = document.querySelector('.sidebar');

// Leer el estado del sidebar del almacenamiento local
const sidebarState = localStorage.getItem('sidebarState');
// Si el estado del sidebar está almacenado, aplicarlo
if (sidebarState === 'open') {
  sidebar.classList.add('open');
}

// Agregar un event listener al botón de la barra lateral
toggleSidebarButton.addEventListener('click', function() {
  // Alternar la clase 'open' en el elemento de la barra lateral
  sidebar.classList.toggle('open');
  // Guardar el estado del sidebar en el almacenamiento local
  const newSidebarState = sidebar.classList.contains('open') ? 'open' : 'closed';
  localStorage.setItem('sidebarState', newSidebarState);
});
