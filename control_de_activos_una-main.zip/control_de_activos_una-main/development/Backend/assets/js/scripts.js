// Obtener el botón de modo oscuro
const darkModeButton = document.querySelector('#dark-mode-button');

// Obtener el modo actual del almacenamiento local
const darkModeEnabled = localStorage.getItem('darkModeEnabled');

// Si el modo oscuro está habilitado en el almacenamiento local, activarlo
if (darkModeEnabled === 'true') {
  document.body.classList.add('dark-mode');
  document.querySelectorAll('.card').forEach(card => {
    card.classList.add('card-dark');
  });
}

// Cuando se hace clic en el botón de modo oscuro
darkModeButton.addEventListener('click', function() {
  // Cambiar el modo oscuro
  document.body.classList.toggle('dark-mode');

  // Cambiar el color de fondo de las tarjetas
  document.querySelectorAll('.card').forEach(card => {
    card.classList.toggle('card-dark');
  });

  // Guardar el modo actual en el almacenamiento local
  const darkModeEnabled = document.body.classList.contains('dark-mode');
  localStorage.setItem('darkModeEnabled', darkModeEnabled);

  // Actualizar el estado del modo oscuro en todas las páginas
  const frames = window.parent.document.getElementsByTagName('iframe');
  for (let i = 0; i < frames.length; i++) {
    frames[i].contentWindow.postMessage({ type: 'updateDarkMode' }, '*');
  }
});






/* CON COOKIES
// Obtener el botón de modo oscuro
const darkModeButton = document.querySelector('#dark-mode-button');

// Obtener el valor actual de la cookie "darkModeEnabled"
const darkModeEnabled = getCookie('darkModeEnabled');

// Si el valor de la cookie es "true", activar el modo oscuro
if (darkModeEnabled === 'true') {
  document.body.classList.add('dark-mode');
}

// Cuando se hace clic en el botón de modo oscuro
darkModeButton.addEventListener('click', function() {
  // Cambiar el modo oscuro
  document.body.classList.toggle('dark-mode');

  // Guardar el estado actual del modo oscuro en una cookie con fecha de expiración de 1 año
  const expirationDate = new Date();
  expirationDate.setFullYear(expirationDate.getFullYear() + 1);
  document.cookie = `darkModeEnabled=${document.body.classList.contains('dark-mode')};expires=${expirationDate.toUTCString()};path=/`;
});

// Función para obtener el valor de una cookie por su nombre
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}


*/