<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <?php
    error_reporting(0);
    include '../business/employeebusiness.php';
    include_once("../session/startsession.php");
    session_start();

    if (isset($_SESSION['employeename'])) {
        $employee_Identification = $_SESSION['id2'];
        $employee_Name = $_SESSION['employeename'];
        $employee_LastName = $_SESSION['employeelastname'];
        $employee_FullName = $employee_Name . " " . $employee_LastName;
        $employee_Phone = $_SESSION['employeephone'];
        $employee_Email = $_SESSION['employeeemail'];
        $employee_Photo = $_SESSION['employeephoto'];
    } else {
        echo "No has iniciado sesion";
    }
    ?>

    <title>Perfil-UNA-Activos</title>

    <!-- Favicons -->
    <link href="https://upload.wikimedia.org/wikipedia/commons/e/e2/LogoUNA.svg" rel="icon">
    <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">



    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">

</head>

<body>
    <style>
        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }

        .success-message {
            color: green;
            font-size: 12px;
            margin-top: 5px;
        }

        .error {
            border-color: red;
        }

        .success {
            border-color: green;
        }

        .success-icon {
            color: green;
            font-size: 12px;
            margin-left: 5px;
        }
    </style>

    <div class="contenedor">
        <!-- ======= Header ======= -->
        <header id="header" class="header fixed-top d-flex align-items-center">

            <a href="../index.php">
                <img src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png" alt="">
            </a>

            <div class="d-flex align-items-center justify-content-between">
                <i class="bi bi-list toggle-sidebar-btn"></i>
            </div>


            <nav class="header-nav ms-auto">
                <ul class="d-flex align-items-center">
                    <li class="nav-item dropdown">

                        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-bell"></i>
                            <span class="badge bg-primary badge-number">4</span>
                        </a><!-- End Notification Icon -->

                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                            <li class="dropdown-header">
                                Tienes 4 notificaciones nuevas
                                <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">Ver todas</span></a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <i class="bi bi-exclamation-circle text-warning"></i>
                                <div>
                                    <h4>Lorem Ipsum</h4>
                                    <p>Quae dolorem earum veritatis oditseno</p>
                                    <p>30 min. ago</p>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <i class="bi bi-x-circle text-danger"></i>
                                <div>
                                    <h4>Atque rerum nesciunt</h4>
                                    <p>Quae dolorem earum veritatis oditseno</p>
                                    <p>1 hr. ago</p>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <i class="bi bi-check-circle text-success"></i>
                                <div>
                                    <h4>Sit rerum fuga</h4>
                                    <p>Quae dolorem earum veritatis oditseno</p>
                                    <p>2 hrs. ago</p>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li class="notification-item">
                                <i class="bi bi-info-circle text-primary"></i>
                                <div>
                                    <h4>Dicta reprehenderit</h4>
                                    <p>Quae dolorem earum veritatis oditseno</p>
                                    <p>4 hrs. ago</p>
                                </div>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li class="dropdown-footer">
                                <a href="#">Ver todas las notificaciones</a>
                            </li>

                        </ul><!-- End Notification Dropdown Items -->

                    </li><!-- End Notification Nav -->

                    <li class="nav-item dropdown pe-3">

                        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                            <?php
                            if (isset($_SESSION['employeephoto']) && !empty($_SESSION['employeephoto'])) {
                                $photoPath = $_SESSION['employeephoto'];
                                echo '<img src="' . $photoPath . '" alt="Profile" class="rounded-circle">';
                            } else {
                                echo '<i class="bi bi-person"></i>';
                            }
                            ?>
                            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $employee_Name ?></span>
                        </a><!-- End Profile Image Icon -->


                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                            <li class="dropdown-header">
                                <h6><?php echo $employee_FullName ?></h6>
                                <span>Funcionario</span>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="users-profile.php">
                                    <i class="bi bi-person"></i>
                                    <span>Mi Perfil</span>
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>


                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="#" onclick="confirmLogout()">
                                    <i class="bi bi-box-arrow-right"></i>
                                    <span>Cerrar Sesión</span>
                                </a>
                            </li>

                        </ul><!-- End Profile Dropdown Items -->
                    </li><!-- End Profile Nav -->

                </ul>
            </nav><!-- End Icons Navigation -->

        </header><!-- End Header -->

        <!-- ======= Sidebar ======= -->
        <aside id="sidebar" class="sidebar">

            <ul class="sidebar-nav" id="sidebar-nav">

                <li class="nav-item">
                    <a class="nav-link " href="../index.php">
                        <i class="bi bi-house-door-fillbi bi-house-door-fill"></i>
                        <span>Principal</span>
                    </a>
                </li><!-- End Dashboard Nav -->


                <li class="nav-item">
                    <a class="nav-link collapsed" href="assetfilterview.php">
                        <i class="bi bi-filter-square-fill"></i>
                        <span>Filtro Activos</span>
                    </a>
                </li><!-- End Dashboard Nav -->

                <!-- <li class="nav-heading">Pages</li> -->



                <li class="nav-item">
                    <a class="nav-link collapsed" href="cargarexcelview.php">
                        <i class="bi bi-cloud-upload-fill"></i>
                        <span>Subir</span>
                    </a>
                </li><!-- End F.A.Q Page Nav -->

                <li class="nav-item">
                    <a class="nav-link collapsed" href="#" id="dark-mode-button">
                        <i class="bi bi-moon-fill"></i>
                        <span>Dark Mode</span>
                    </a>
                </li>

            </ul>

        </aside><!-- End Sidebar-->

        <main id="main" class="main">

            <div class="pagetitle">
                <h1>Perfil</h1>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Inicio</a></li>
                        <li class="breadcrumb-item">Usuarios</li>
                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </nav>
            </div><!-- End Page Title -->

            <section class="section profile">
                <div class="row">
                    <div class="col-xl-4">

                        <div class="card">
                            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                                <?php
                                if (isset($_SESSION['employeephoto']) && !empty($_SESSION['employeephoto'])) {
                                    $photoPath = $_SESSION['employeephoto'];
                                    echo '<img src="' . $photoPath . '" alt="Foto del empleado" class="rounded-circle">';
                                } else {
                                    echo 'No hay foto disponible';
                                }
                                ?>
                                <h2><?php echo $employee_Name ?></h2>
                                <h>Funcionario</h>
                            </div>
                        </div>

                    </div>

                    <div class="col-xl-8">

                        <div class="card">
                            <div class="card-body pt-3">
                                <!-- Bordered Tabs -->
                                <ul class="nav nav-tabs nav-tabs-bordered">

                                    <li class="nav-item">
                                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Visión general</button>
                                    </li>


                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-create-account">Registro Funcionario</button>
                                    </li>

                                </ul>
                                <div class="tab-content pt-2">
                                    <?php
                                    // Obtener el ID del empleado de la sesión
                                    $employeeId = $_SESSION['employeeid'];

                                    // Obtener los datos del empleado desde la base de datos
                                    $employeeBusiness = new employeebusiness();
                                    $employee = $employeeBusiness->getTBEmployeeById($employeeId);

                                    ?>
                                    <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                        <h5 class="card-title">Detalles Perfil</h5>
                                        <input type="hidden" name="employeeId" value="' . $current->getEmployee_Id() . '">
                                        <div class="row">
                                            <div class="col-lg-3 col-md-4 label ">Nombre Completo</div>
                                            <div class="col-lg-9 col-md-8"><?php echo $employee->getEmployee_Name() . ' ' . $employee->getEmployee_LastName(); ?></div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-3 col-md-4 label">Trabajo</div>
                                            <div class="col-lg-9 col-md-8">Funcionario</div>
                                        </div>


                                        <div class="row">
                                            <div class="col-lg-3 col-md-4 label">Telefono</div>
                                            <div class="col-lg-9 col-md-8">(+506) <?php echo $employee->getEmployee_Phone(); ?></div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-3 col-md-4 label">Email</div>
                                            <div class="col-lg-9 col-md-8"><?php echo $employee->getEmployee_Email(); ?></div>
                                        </div>

                                        <div class="row mt-3">
                                            <div class="col-lg-12 col-md-12">
                                                <div class="text-center mb-3">
                                                    <button onclick="location.href='edit-profile.php'" class="btn btn-primary">Editar Perfil</button>
                                                    <button class="btn btn-danger delete_employee" id="eliminarEmpleado" name="eliminarEmpleado" employeeId="<?php echo $employee->getEmployee_Id(); ?>">Eliminar</button>
                                                    <!-- <button onclick="location.href='change-password.php'"
                                                        class="btn btn-secondary">Cambiar Contraseña</button> -->
                                                    <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                                        Cambiar Contraseña
                                                    </button>
                                                </div>
                                                <!-- Cambiar contrasenia en el perfil -->
                                                <div class="collapse" id="collapseExample">
                                                    <div class="card card-body">
                                                        <h5 class="card-title mt-1">Cambiar contraseña</h5>
                                                        <form id="form">
                                                            <input type="hidden" id="identificacion" value="<?php echo $employee_Identification; ?> ">
                                                            <div class="col">
                                                                <input type="password" id="passwordactual" placeholder="Ingrese su contraseña actual" class="form-control" required>
                                                            </div>
                                                            <div class="col mt-2">
                                                                <input type="password" id="password" placeholder="Ingrese la nueva contraseña" class="form-control" required>
                                                            </div>
                                                            <div class="col mt-2">
                                                                <input type="password" id="passwordc" placeholder="Confirme su contraseña" class="form-control" required>
                                                            </div>
                                                            <div class="col-sm">
                                                                <button type="button" id="reset-password" class="btn btn-success mt-2">Guardar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                                        <!-- Profile Edit Form BORRAR-->
                                        <form>
                                            <div class="row mb-3">
                                                <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Foto
                                                    Perfil</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <img src="../assets/img/me.jpg" alt="Profile">
                                                    <div class="pt-2">
                                                        <!-- Llamar a la db para borrar o actualizar la foto -->
                                                        <a href="#" class="btn btn-primary btn-sm" title="Upload new profile image"><i class="bi bi-upload"></i></a>
                                                        <a href="#" class="btn btn-danger btn-sm" title="Remove my profile image"><i class="bi bi-trash"></i></a>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Nombre
                                                    Completo</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input name="fullName" type="text" class="form-control" id="fullName" value="Giancarlo Arrrr">
                                                </div>
                                            </div>


                                            <div class="row mb-3">
                                                <label for="Job" class="col-md-4 col-lg-3 col-form-label">Trabajo</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input name="job" type="text" class="form-control" id="Job" value="Funcionario">
                                                </div>
                                            </div>


                                            <div class="row mb-3">
                                                <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Telefono</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input name="phone" type="text" class="form-control" id="Phone" value="(506) 65749874">
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="Email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input name="email" type="email" class="form-control" id="Email" value="giancarlo.@est.una.ac.cr">
                                                </div>
                                            </div>



                                            <div class="text-center">
                                                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                            </div>
                                        </form><!-- End Profile Edit Form -->

                                    </div>



                                    <div class="tab-pane fade pt-3" id="profile-create-account">
                                        <!-- Create Account Form -->
                                        <form method="POST" enctype="multipart/form-data" action="../business/employeeaction.php" id="registerForm">

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Cédula</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input required name="employeeidentification" type="text" class="form-control" id="employeeidentification" oninput="validationIdentification()" placeholder="Ejemplo: 1 0111 0111">
                                                    <span id="identificationError" class="error-message"></span>
                                                    <span id="identificationSuccess" class="success-message"></span>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Nombre</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input require name="employeename" type="text" class="form-control" id="employeename">
                                                    <span id="nameError" class="error-message"></span>
                                                    <span id="nameSuccess" class="success-message"></span>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Apellidos</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input require name="employeelastname" type="text" class="form-control" id="employeelastname">
                                                    <span id="lastnameError" class="error-message"></span>
                                                    <span id="lastnameSuccess" class="success-message"></span>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Telefono</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input require name="employeephone" type="text" class="form-control" id="employeephone" oninput="validatePhoneNumber()">
                                                    <span id="phoneError" class="error-message"></span>
                                                    <span id="phoneSuccess" class="success-message"></span>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Correo</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input require name="employeeemail" type="text" class="form-control" id="employeeemail" placeholder="Ejemplo@est.una.ac.cr">
                                                    <span id="emailError" class="error-message"></span>
                                                    <span id="emailSuccess" class="success-message"></span>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Crear Contraseña</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input require name="employeepassword" type="password" class="form-control" id="employeepassword" placeholder="Debe contener al menos 8 caracteres!">
                                                    <span id="passwordError" class="error-message"></span>
                                                    <span id="passwordSuccess" class="success-message"></span>

                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <label class="col-md-4 col-lg-3 col-form-label">Foto</label>
                                                <div class="col-md-8 col-lg-9">
                                                    <input required name="employeephoto" type="file" class="form-control" id="employeephoto">
                                                </div>
                                            </div>


                                            <div class="text-center">
                                                <button type="submit" value="Crear" name="create" class="btn btn-primary">Crear Cuenta</button>
                                            </div>
                                        </form><!-- End Change Password Form -->

                                    </div>

            </section>

        </main><!-- End #main -->

        <!-- ======= Footer ======= -->
        <footer id="footer" class="footer">
            <div class="credits">© <?php echo date("Y"); ?>
                | Universidad Nacional Campus Sarapiquí, Costa Rica.
            </div>
        </footer><!-- End Footer -->
    </div>
    <script src="../assets/jquery/jquery-3.3.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.delete_employee').click(function() {
                var employeeId = $(this).attr('employeeid');

                Swal.fire({
                    title: '¿Desea eliminar el empleado?',
                    text: 'No se podrá revertir el cambio',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: 'Cancelar',
                    confirmButtonText: 'Eliminar'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirigir a la página para eliminar el empleado con el employee_id en la URL
                        window.location.href = '../business/employeeaction.php?delete=true&employeeid=' + employeeId;
                    }
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            const $btnresetpassword = $("#reset-password");
            $btnresetpassword.click(function() {
                if ($("#identificacion").val() !== '' &&
                    $("#passwordactual").val() !== '' && $("#password").val() !== '' && $("#passwordc").val() !== '') {
                    $.post("../business/employeeaction.php", {
                        action: 'change-password',
                        identification: $.trim($("#identificacion").val()),
                        passwordactual: $.trim($("#passwordactual").val()),
                        password: $.trim($("#password").val()),
                        passwordc: $.trim($("#passwordc").val())
                    }, function(response) {
                        $("#form").trigger('reset');
                        const result = JSON.parse(response);
                        if (result.error === 'validatecurrentpassword') {
                            mostrarMensaje('La contraseña actual es incorrecto!', 'error')
                        } else if (result.error === 'passwordverify') {

                            mostrarMensaje('Las nuevas contraseñas no coinciden!', 'error')
                        } else if (result.error === 'notchangedpassword') {

                            mostrarMensaje('No se pudo cambiar las contraseñas!', 'error')
                        } else if (result.success === 'changedpassword') {

                            mostrarMensaje('Contraseña cambiada exitosamente!', 'success')
                        }
                    })
                } else {
                    mostrarMensaje('Completa los campos del formulario!', 'warning')
                }
            });

            function mostrarMensaje(mensaje, type) {
                if (type === 'error') {
                    Swal.fire('Ups!', mensaje, 'error')
                } else if (type === 'success') {
                    Swal.fire('Genial!', mensaje, 'success')
                } else {
                    Swal.fire('Ups!', mensaje, 'warning')
                }
            }
        });
    </script>
    <script>
        function confirmLogout() {
            Swal.fire({
                icon: 'question',
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar la sesión?',
                showCancelButton: true,
                confirmButtonText: 'Confirmar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Aquí puedes redirigir o ejecutar la lógica para cerrar la sesión
                    window.location.href = '../Session/closesession.php';
                }
            });
        }

        function validationIdentification() {
            var cedulaInput = document.getElementById("employeeidentification");
            var cedulaValue = cedulaInput.value.trim();

            if (cedulaValue.length == 9) {
                cedulaValue = cedulaValue.replace(/\D/g, "").substr(0, 9);
                cedulaValue = cedulaValue.replace(/(\d{1})(\d{4})(\d{4})/, "$1-$2-$3");
                cedulaInput.value = cedulaValue;
            }
        }

        function validatePhoneNumber() {

            var phone = document.getElementById("employeephone");

            if (phone.value.length == 8) {
                phone.value = phone.value.replace(/\D/g, "").substr(0, 8);
                phone.value = phone.value.replace(/(\d{4})(\d{4})/, "(+506) $1-$2");
            }
        }
    </script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chart.js/chart.min.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.min.js"></script>
    <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>


    <!-- Template Main JS File -->
    <script src="../assets/js/main.js"></script>
    <script src="../validations/validateRegisterForm.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>