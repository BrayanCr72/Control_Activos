<?php
session_start();
$sessData = !empty($_SESSION['sessData']) ? $_SESSION['sessData'] : '';
if (!empty($sessData['status']['msg'])) {
	$statusMsg = $sessData['status']['msg'];
	$statusMsgType = $sessData['status']['type'];
	unset($_SESSION['sessData']['status']);
}
?>
<!DOCTYPE html>
<html>

<head>
	<title> Cambio de Contraseña </title>
	<link rel="stylesheet" href="../css/forgotresetpasswordstyle.css" type="text/css" media="all" />
	<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900" type="text/css" media="all">
</head>

<body>
	<!-- <h1> Cambio de Contraseña </h1> -->
	<div class="container">
		<div class="regisFrm">
			<h4>Resetea la Contraseña de tu Cuenta</h4>
			<?php echo !empty($statusMsg) ? '<small class="' . $statusMsgType . '">' . $statusMsg . '</small>' : ''; ?>
			<form action="../business/useraccountaction.php" method="post">
				<input type="password" name="password" placeholder="Contraseña" required="">
				<input type="password" name="confirm_password" placeholder="Confirma tu Contraseña" required="">
				<div class="send-button">
					<input type="hidden" name="fp_code" value="<?php echo isset($_REQUEST['fp_code']) ? $_REQUEST['fp_code'] : '' ?>" />
					<!-- <input type="submit" name="resetSubmit" value="Resetea Contraseña"> -->
					<button type="submit" name="resetSubmit">Resetea Contraseña</button>
				</div>
			</form>
		</div>
	</div>
</body>

</html>