<?php
session_start();
$sessData = !empty($_SESSION['sessData']) ? $_SESSION['sessData'] : '';
if (!empty($sessData['status']['msg'])) {
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title> Cambio de Contraseña </title>
    <link rel="stylesheet" href="../css/forgotresetpasswordstyle.css" type="text/css" media="all" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900" type="text/css" media="all">
</head>

<body>
    <!-- <a href="index.php">
        <h1> Cambio de Contraseña </h1>
    </a> -->
    <div class="container">
        <div class="regisFrm">
            <h4>Cambio de Contraseña</h4>
            <?php echo !empty($statusMsg) ? '<small class="' . $statusMsgType . '">' . $statusMsg . '</small>' : ''; ?>
            <form action="../business/useraccountaction.php" method="post">
                <input type="email" name="email" placeholder="Ingrese su correo electr&oacute;nico" required="">
                <!-- <div class="send-button"> -->
                    <!-- <input type="submit" name="forgotSubmit" value="Continuar"> -->
                    <button type="submit" name="forgotSubmit">Continuar</button>
                <!-- </div> -->
            </form>
        </div>
    </div>
</body>

</html>