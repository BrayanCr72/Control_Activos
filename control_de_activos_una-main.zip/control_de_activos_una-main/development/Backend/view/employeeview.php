<!DOCTYPE html>

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Registro Funcionario</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <?php
      error_reporting(0);
    include '../business/employeebusiness.php';
   
    ?>

</head>

<body>
    <h2>
        <a href="../index.php">Home</a>
    </h2>
    <section id="form">

        <table>
            <tr>
                <th>Cedula Funcionario</th>
                <th>Nombre Funcionario</th>
                <th>Apellidos Funcionario</th>
                <th>Telefono Funcionario</th>
                <th>Correo Funcionario</th>
                <th>Contraseña Funcionario</th>
                <th>Activo</th>
            </tr>

            <tbody id="tabla">

            <form method="POST" enctype="multipart/form-data" action="../business/employeeaction.php">
                <tr>
                    
                    <td><input required type="text" name="employeeidentification" id="employeeidentification"/></td>
                    <td><input required type="text" name="employeename" id="employeename"/></td>
                    <td><input required type="text" name="employeelastname" id="employeelastname"/></td>
                    <td><input required type="text" name="employeephone" id="employeephone"/></td>
                    <td><input required type="text" name="employeeemail" id="employeeemail"/></td>
                    <td><input required type="password" name="employeepassword" id="employeepassword"/></td>
                    <td></td>
                    <td><input type="submit" value="Crear" name="create" id="submit"/></td>
                </tr>
            </form>
            <?php
             error_reporting(0);
            $employeeBusiness = new EmployeeBusiness();
            $allEmployee = $employeeBusiness->getAllTBEmployee();
            foreach ($allEmployee as $current) {
                echo '<form method="post" class="formEmployee" enctype="multipart/form-data" action="../business/employeeaction.php">';
                echo '<input type="hidden" name="employeeid" value="' . $current->getEmployee_Id() . '">';
                echo '<tr>';
                echo '<td><input type="text" name="employeeidentification" id="employeeidentification" value="' . $current->getEmployee_Identification() . '"/></td>';
                echo '<td><input type="text" name="employeename" id="employeename" value="' . $current->getEmployee_Name() . '"/></td>';
                echo '<td><input type="text" name="employeelastname" id="employeelastname" value="' . $current->getEmployee_Lastname() . '"/></td>';
                echo '<td><input type="text" name="employeephone" id="employeephone" value="' . $current->getEmployee_Phone() . '"/></td>';
                echo '<td><input type="text" name="employeeemail" id="employeeemail" value="' . $current->getEmployee_Email() . '"/></td>';
                echo '<td><input type="password" name="employeepassword" id="employeepassword" value="' . $current->getEmployee_Password() . '"/></td>';
                

                if($current->getEmployee_Active() == 1){
                    echo '<td><input checked type="checkbox" id="employeeactive" name="employeeactive" ></td>';
                }else{
                    echo '<td><input type="checkbox" id="employeeactive" name="employeeactive" ></td>';
                }
                echo '<td><input type="submit" value="Actualizar" name="update" id="update"/></td>';
                echo '<td><input type="submit" value="Eliminar" name="delete" id="delete"/></td>';
                echo '</tr>';
                echo '</form>';
            }
            ?>


            <tr>
                <td></td>
                <td>
                    <?php
                    error_reporting(0);
                    if (isset($_GET['error'])) {
                        if ($_GET['error'] == "emptyField") {
                            echo '<p style="color: red">Campo(s) vacio(s)</p>';
                        } else if ($_GET['error'] == "numberFormat") {
                            echo '<p style="color: red">Error, formato de numero</p>';
                        } else if ($_GET['error'] == "dbError") {
                            echo '<center><p style="color: red">Error al procesar la transacción</p></center>';
                        }
                    } else if (isset($_GET['success'])) {
                        echo '<p style="color: green">Transacción realizada</p>';
                    }
                    ?>
                </td>
            </tr>
            </tbody>
        </table>
    </section>
 
</body>
</html>