<?php
session_start();
$sessData = !empty($_SESSION['sessData']) ? $_SESSION['sessData'] : '';
if (!empty($sessData['status']['msg'])) {
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title> UNA </title>

    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <link href="../assets/css/style.css" rel="stylesheet">



    <!--<link rel="stylesheet" type="text/css" href="../css/style.css" />-->
    <style>
        h1 {
            color: red;
        }
    </style>
</head>
<!-- https://lh3.googleusercontent.com/p/AF1QipMoEp3ch_HHbyQsHbIqm3SKDr1jd8aomRAAbh3Y=s1360-w1360-h1020 -->
<!-- style="background: url('https://www.srhnc.una.ac.cr/images/Para_Portada.jpg')no-repeat; background-size: cover;" -->

<body>

    <main>
        <div class="container">
            <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
                            <div class="card mb-3">
                                <div align="center">
                                    <img width="60%" height="100%" src="https://eis.una.ac.cr/authenticationendpoint/images/una-logo.png" alt="">
                                </div>
                                <div class="pt-4 pb-2">
                                    <h5 class="card-title text-center pb-0 fs-4">Reactivar cuenta</h5>
                                </div>
                                <div class="card-body">
                                    <?php echo !empty($statusMsg) ? '<p class="' . $statusMsgType . '">' . $statusMsg . '</p>' : ''; ?>
                                    <div class="regisFrm">
                                        <form action="../business/useraccountaction.php" method="post" class="row g-3 needs-validation">
                                            <div class="col-12">
                                                <input type="text" name="username_email" placeholder="Correo electrónico" required="">
                                                <div class="invalid-feedback">Por favor ingrese un correo electrónico válido.</div>
                                            </div>
                                            <div class="col-12">
                                                <input type="password" name="password" placeholder="Contraseña" required="">
                                                <div class="invalid-feedback">Por favor ingrese una contraseña.</div>
                                            </div>
                                            <div class="send-button">
                                                <input type="submit" name="reactivate" value="Reactivar cuenta">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>



</body>
<script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</html>