<?php

include '../business/assetbusiness.php';
include_once("../session/startsession.php");

//$clienteTipoBusiness = new ClienteTipoBusiness();
//$asset = new assetbusiness();.
//$AllAsset =  $asset->getAsset();

$servidor = "localhost";
$usuario = "root";
$password = "";
$nombreBD = "dbactivos";
$conexion = new mysqli($servidor, $usuario, $password, $nombreBD);
if ($conexion->connect_error) {
    die("la conexión ha fallado: " . $conexion->connect_error);
}

if (!isset($_POST['buscar'])) {
    $_POST['buscar'] = '';
}
if (!isset($_POST['identificadoractivo'])) {
    $_POST['identificadoractivo'] = '';
}
if (!isset($_POST['nombrefuncionario'])) {
    $_POST['nombrefuncionario'] = '';
}
if (!isset($_POST['valorenlibrosdesde'])) {
    $_POST['valorenlibrosdesde'] = '';
}
if (!isset($_POST['valorenlibroshasta'])) {
    $_POST['valorenlibroshasta'] = '';
}
if (!isset($_POST['condicion'])) {
    $_POST['condicion'] = '';
}


//obtener datos de la session 
if (isset($_SESSION['employeeid'])) {

    $employee_Name = $_SESSION['employeename'];
    $employee_LastName = $_SESSION['employeelastname'];
    $employee_FullName = $employee_Name . " " . $employee_LastName;
} else {
    echo "No has iniciado sesion";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filtro-Activos</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- <link rel="stylesheet" href="http://localhost/Activos/development/Backend/css/bootstrap.min.css"> -->


    </link>
    <link href="../css/estilos.css" rel="stylesheet">
    <!-- Icono UNA pestaña -->
    <link href="../assets/img/LogoUNA.svg" rel="icon">

    <!-- Vendor CSS Files -->
    <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">

    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="../assets/datatables/datatables.min.css" />
    <!--datables estilo bootstrap 4 CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">

    <!--font awesome con CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">


    <style>
        .dropbtn {
            background-color: #a31e32;
            color: white;
            padding: 10px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        .dropbtn:hover,
        .dropbtn:focus {
            background-color: #a31e32;
        }

        #myInput {
            box-sizing: border-box;
            background-image: url('searchicon.png');
            background-position: 14px 12px;
            background-repeat: no-repeat;
            font-size: 16px;
            padding: 14px 20px 12px 45px;
            border: none;
            border-bottom: 1px solid #ddd;
        }

        #myInput:focus {
            outline: 3px solid #ddd;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f6f6f6;
            min-width: 230px;
            overflow: auto;
            border: 1px solid #ddd;
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown a:hover {
            background-color: #ddd;
        }

        .show {
            display: block;
        }
    </style>


    <!-- Template Main CSS File -->
    <link href="../assets/css/style.css" rel="stylesheet">

</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

        <a href="../index.php">
            <img src="https://www.una.ac.cr/wp-content/uploads/2020/10/logo_una.png" alt="">
        </a>

        <div class="d-flex align-items-center justify-content-between">
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div>


        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <li class="nav-item dropdown">

                    <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-bell"></i>
                        <span class="badge bg-primary badge-number">4</span>
                    </a><!-- End Notification Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                        <li class="dropdown-header">
                            Tienes 4 nofiticaciones nuevas
                            <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">Ver todas</span></a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-exclamation-circle text-warning"></i>
                            <div>
                                <h4>Lorem Ipsum</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>30 min. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-x-circle text-danger"></i>
                            <div>
                                <h4>Atque rerum nesciunt</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>1 hr. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Sit rerum fuga</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>2 hrs. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-info-circle text-primary"></i>
                            <div>
                                <h4>Dicta reprehenderit</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>4 hrs. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li class="dropdown-footer">
                            <a href="#">Mostrar todas las notificaciones</a>
                        </li>

                    </ul><!-- End Notification Dropdown Items -->

                </li><!-- End Notification Nav -->



                <li class="nav-item dropdown pe-3">

                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <?php
                        if (isset($_SESSION['employeephoto']) && !empty($_SESSION['employeephoto'])) {
                            $photoPath = $_SESSION['employeephoto'];
                            echo '<img src="' . $photoPath . '" alt="Profile" class="rounded-circle">';
                        } else {
                            echo '<i class="bi bi-person"></i>';
                        }
                        ?>
                        <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $employee_Name ?></span>
                    </a><!-- End Profile Image Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?php echo $employee_FullName ?></h6>
                            <span>Funcionario</span>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <!-- The user selects the section of my profile --> 
                            <a class="dropdown-item d-flex align-items-center" href="users-profile.php">
                                <i class="bi bi-person"></i>
                                <span>Mi Perfil</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <!-- The session was closed -->
                            <a class="dropdown-item d-flex align-items-center" href="#" onclick="confirmLogout()">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Cerrar Sesión</span>
                            </a>
                        </li>

                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->

    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">
           <!--Button to return to the beginning-->             
            <li class="nav-item">
                <a class="nav-link " href="../index.php">
                    <i class="bi bi-house-door-fillbi bi-house-door-fill"></i>
                    <span>Inicio</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <li class="nav-item">
                <!-- Button to filter the registered assets -->
                <a class="nav-link collapsed" href="assetfilterview.php">
                    <i class="bi bi-filter-square-fill"></i>
                    <span>Filtro Activos</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <li class="nav-item">
                <!-- Button to upload excel -->
                <a class="nav-link collapsed" href="cargarexcelview.php">
                    <i class="bi bi-cloud-upload-fill"></i>
                    <span>Subir</span>
                </a>
            </li><!-- End F.A.Q Page Nav -->

        </ul>

    </aside><!-- End Sidebar-->

    <main id="main" class="main">

        <form id="form2" name="form2" method="POST" action="assetfilterview.php">

            <div class="container">
                <div class="col-12 row">


                    <h4 class="card-title">Buscador</h4>

                    <div class="mb-3">
                        <!-- The search for the assets is carried out by means of the filter -->
                        <label class="form-label">Activo a buscar</label>
                        <input type="text" class="form-control" id="buscar" name="buscar" value="<?php echo $_POST["buscar"]  ?>">
                    </div>

                    <h4 class="card-title">Filtro de búsqueda</h4>


                    <div class="col-11">

                        <table class="table">
                            <thead>
                                <tr class="filters">
                                    
                                    <th>
                                        Condición
                                        <!-- The condition of the asset is selected.-->  
                                        <select id="condicion" name="condicion" style="border: #bababa 1px solid; color:#000000;">
                                            <?php if ($_POST["condicion"] != '') { ?>
                                                <option value="<?php echo $_POST["condicion"]; ?>">
                                                    <?php echo $_POST["condicion"]; ?> </option>
                                            <?php } ?>

                                            <option value="">Todos</option>
                                            <option value="En uso">En uso</option>
                                            <option value="En desuso">En desuso</option>

                                        </select>
                                    </th>

                                </tr>
                            </thead>
                        </table>
                    </div>

                    <div class="col-1">
                        <input type="submit" class="btn btn-success" value="Filtrar">
                    </div>
                </div>

                <?php
                //The instances are made to call the filter asset..
                $data = new assetdata();

                $query = $data->createFilterAsset();
                $sql = $conexion->query($query);
                $numeroSql = mysqli_num_rows($sql);
                ?>
                <!--The results are found.-->
                <p><?php echo $numeroSql; ?> resultados encontrados</p>
        </form>
        </div>

        <?php
        if (isset($_POST["buscar"])) {

            $assets = $data->getAssetByName($_POST['buscar']);
        }
        ?>

        <div class="row">
            <form class="form-inline" action="assetfilterview.php" method="post">

                <?php if (!empty($assets)) { ?>
                    <div class="form-group">
                        <select class="form-select mb-2" name="assetid" id="assetid" required>
                            <!-- Se selecciona el número de etiqueta--> 
                            <option disabled selected value="">Seleccione</option>
                            <?php foreach ($assets as $asset) { ?>
                                <option value="<?php echo $asset->getAsset_Label_Number() ?> ">
                                    <?php echo $asset->getAsset_Label_Number() ?></option>
                            <?php } ?>< </select>
                                <textarea class="form-control mb-2" name="observation" id="observation" cols="15" rows="2" placeholder="Ingrese observaci&oacute;n..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mb-3">Agregar</button>
                <?php } ?>

                <?php
                $data = new assetdata();
                if (isset($_POST['assetid']) && isset($_POST['observation'])) {

                    $result = $data->addObservation($_POST['assetid'], $_POST['observation']);

                    if (!empty($result)) {
                        echo $result;
                    }
                }
                ?>
            </form>
            <hr>
        </div>

        <div class="col-lg-12">
            <!--A  table is created for the assets-->
            <div class="row">
                <div class="table-responsive">
                    <!-- class="table table-striped table-bordered border  table-sm" -->
                    <p></p>
                    <table id="tablaSigesa" class="table table-striped table-bordered border  table-sm">

                        <thead>
                            <tr>
                                <!--<th scope="col">Identificador del activo</th>-->
                                <th scope="col">Numero de Etiqueta</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Marca</th>
                                <th scope="col">Modelo</th>
                                <th scope="col">Serie</th>
                                <th scope="col">Valor en Libros</th>
                                <th scope="col">Condición</th>
                                <th scope="col">Clase Activo</th>
                                <th scope="col">Identificación Funcionario</th>
                                <th scope="col">Nombre Funcionario</th>
                                <th scope="col">Observaci&oacute;n</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php while ($asset = $sql->fetch_assoc()) {   ?>

                                <tr>
                                    <td><?php echo $asset["AssetLabelNumber"]; ?></td>
                                    <td><?php echo $asset["AssetDescription"]; ?></td>
                                    <td><?php echo $asset["AssetBrand"]; ?></td>
                                    <td><?php echo $asset["AssetModel"]; ?></td>
                                    <td><?php echo $asset["AssetSire"]; ?></td>
                                    <td><?php echo $asset["ValuesBooks"]; ?></td>
                                    <td><?php echo $asset["AssetCondition"]; ?></td>
                                    <td><?php echo $asset["AssetClass"]; ?></td>
                                    <td><?php echo $asset["IdEmployee"]; ?></td>
                                    <td><?php echo $asset["EmployeeName"]; ?></td>
                                    <td><?php echo !empty($asset['observation']) ? $asset['observation'] : 'Sin Observación' ?>
                                    </td>
                                </tr>

                            <?php } ?>
                        </tbody>
                    </table>

                    <?php
                    require "../template/footer.php";

                    ?>
                </div>
            </div>
        </div>
        <section class="section dashboard">
        </section>
        <!-- End #main -->
    </main>
    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="credits">© <?php echo date("Y"); ?>
            | Universidad Nacional Campus Sarapiquí, Costa Rica.
        </div>
    </footer>
    <!-- End Footer -->

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="../assets/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/popper/popper.min.js"></script>
    <script src="../assets/bootstrap/js/bootstrap.min.js"></script>

    <!-- datatables JS -->
    <script type="text/javascript" src="../assets/datatables/datatables.min.js"></script>

    <!-- para usar botones en datatables JS -->
    <script src="../assets/datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>
    <script src="../assets/datatables/JSZip-2.5.0/jszip.min.js"></script>
    <script src="../assets/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
    <script src="../assets/datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="../assets/datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.1.2/js/buttons.html5.styles.min.js">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.1.2/js/buttons.html5.styles.templates.min.js">
    </script>

    <script>
        $(document).ready(function() {

            $('#tablaSigesa').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-ES.json'
                },
                responsive: "true",
                dom: 'Bfrtilp',
                buttons: [{
                        extend: 'excelHtml5',
                        excelStyles: [{
                                template: 'green_medium', // Apply the 'green_medium' template
                            },
                            {
                                cells: 'sh', // Use Smart References (s) to target the header row (h)
                                style: {
                                    // Add a style block
                                    font: {
                                        // Style the font
                                        size: 14, // Size 14
                                        b: false, // Turn off the default bolding of the header
                                    },
                                    fill: {
                                        // Style the fill/background
                                        pattern: {
                                            // Add a pattern (default type is solid)
                                            color: 'F95146' //'1C3144', // Define the color
                                        }
                                    },
                                }
                            }
                        ],
                        exportOptions: {
                            formart: {
                                body: function(data, row, column, node) {
                                    return {
                                        style: {
                                            alignment: {
                                                horizontal: 'center'
                                            }
                                        },
                                        value: data
                                    };
                                }
                            }
                        },
                        text: '<i class="fas fa-file-excel"></i> ',
                        titleAttr: 'Exportar a Excel',
                        className: 'btn btn-success',

                    },
                    {
                        extend: 'pdfHtml5',
                        orientation: 'landscape',
                        pageSize: 'LEGAL',
                        text: '<i class="fas fa-file-pdf"></i> ',
                        titleAttr: 'Exportar a PDF',
                        className: 'btn btn-danger'
                    },
                    {
                        extend: 'print',
                        orientation: 'landscape',
                        pageSize: 'LEGAL',
                        text: '<i class="fa fa-print"></i> ',
                        titleAttr: 'Imprimir',
                        className: 'btn btn-secondary'
                    },
                ],
                "columnDefs": [{
                    "className": "text-center",
                    "targets": "_all"
                }]
            });
        });

        function confirmLogout() {
            Swal.fire({
                icon: 'question',
                title: '¿Estás seguro?',
                text: '¿Deseas cerrar la sesión?',
                showCancelButton: true,
                confirmButtonText: 'Confirmar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Aquí puedes redirigir o ejecutar la lógica para cerrar la sesión
                    window.location.href = '../Session/closesession.php';
                }
            });
        }
    </script>



    <!-- código JS propìo-->
    <script type="text/javascript" src="main.js"></script>

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/vendor/chart.js/chart.min.js"></script>
    <script src="../assets/vendor/echarts/echarts.min.js"></script>
    <script src="../assets/vendor/quill/quill.min.js"></script>
    <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="../assets/js/main.js"></script>
    <script src="../assets/js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>


</html>