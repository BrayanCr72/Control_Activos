const identification = document.getElementById('employeeidentification');
const name = document.getElementById('employeename');
const lastname = document.getElementById('employeelastname');
const email = document.getElementById('employeeemail');
const phone = document.getElementById('employeephone');
const password = document.getElementById('employeepassword');
const form = document.getElementById('registerForm');

form.addEventListener('submit', (e) => {
    

    let validationEmail = /^[\w.-]+(\.[\w.-]+)*@est\.una\.ac\.cr$/;
    const imageRegex = /\.(jpeg|jpg|gif|png|bmp)$/i;
    let flag = false;
    
    // validate that the identificación has 9 digits
    if (identification.value.length < 9 ) {
        showError('identificationError', "La identificación debe tener 9 dígitos");
        flag = true;
    }else if(imageRegex.test(identification.value)){
        showError('identificationError', "La identificación no puede ser una URL de imagen");
        flag = true;
    }else {
        clearError('identificationError');

    }
    if(phone.value.length < 8 ){
        showError('phoneError', "El número de telefono debe tener 8 dígitos");
        flag = true;
    }else if(imageRegex.test(phone.value)){
        showError('phoneError', "El número no puede ser una URL de imagen");
        flag = true;
    }else {
        clearError('phoneError');

    }

    // validate that the email is institutional
    if (!validationEmail.test(email.value)) {
        showError('emailError', "El correo debe ser institucional");
        flag = true;
    }else if(imageRegex.test(email.value)){
        showError('identificationError', "El correo no puede ser una URL de imagen");
        flag = true;
    } else {
        clearError('emailError');
        showSuccess('emailSuccess');
    }

    // validate that the name does not contain numbers
    if (!isNaN(name.value)) {
        showError('nameError', "El nombre no puede contener números");
        flag = true;    
    }else if(imageRegex.test(name.value)){
        showError('nameError', "El nombre no puede ser una URL de imagen");
        flag = true;
    } else {
        clearError('nameError');
        showSuccess('nameSuccess');
    }

    // validate that the lastname does not contain numbers
    if (!isNaN(lastname.value)) {
        showError('lastnameError', "El apellido no puede contener números");
        flag = true;

    }else if(imageRegex.test(lastname.value)){
        showError('lastnameError', "El apellido no puede ser una URL de imagen");
        flag = true;
    } else {
        clearError('lastnameError');
        showSuccess('lastnameSuccess');
    }

    // validate that the password has 1 word, 1 number, and 8 characters
    if (password.value.length < 8) {
        showError('passwordError', "La contraseña debe tener al menos 8 caracteres");
        flag = true;
    }else if(imageRegex.test(password.value)){
        showError('passwordError', "La contraseña no puede ser una URL de imagen");
        flag = true;
    } else {
        clearError('passwordError');
        showSuccess('passwordSuccess');
    }
    if(flag){
        e.preventDefault();
    }

   
});

function showError(errorId, errorMessage) {
    const errorElement = document.getElementById(errorId);
    errorElement.textContent = errorMessage;
}

function clearError(errorId) {
    const errorElement = document.getElementById(errorId);
    errorElement.textContent = "";
}
function showSuccess(successId) {
    const successElement = document.getElementById(successId);
    successElement.innerHTML = '<i class="fas fa-check success-icon"></i>';
}

function clearSuccess(successId) {
    const successElement = document.getElementById(successId);
    successElement.textContent = "";
}