<?php
include_once('../domain/asset.php');
include_once('../business/cargararchivobusiness.php');
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

if (isset($_POST['upload'])){

   
    if(isset($_FILES["file"])) {
        $file = $_FILES["file"]["tmp_name"];

        if ((strlen( $file) > 0)){
            $dataFile = [];

            $document = IOFactory::load($file);//load file
            $sheetCurrent = $document->getSheet(0);
            $rowNumber = $sheetCurrent->getHighestDataRow();//get row number
            $word = $sheetCurrent->getHighestColumn();
            $wordNumber = Coordinate::columnIndexFromString($word);//get column number

            for($i =2; $i < $rowNumber; $i++){
                $asset_Label_Number = $sheetCurrent->getCellByColumnAndRow(1,$i)->getValue();
                $asset_Description = $sheetCurrent->getCellByColumnAndRow(1,$i)->getValue();
                $asset_Brand = $sheetCurrent->getCellByColumnAndRow(2,$i)->getValue();
                $asset_Model = $sheetCurrent->getCellByColumnAndRow(3,$i)->getValue();

                //Apartir de aquí funcionaba
                $asset_Sire = $sheetCurrent->getCellByColumnAndRow(4,$i)->getValue();
                $asset_ValuesBooks = $sheetCurrent->getCellByColumnAndRow(5,$i)->getValue();
                $asset_Condition = $sheetCurrent->getCellByColumnAndRow(6,$i)->getValue();
                $asset_Class = $sheetCurrent->getCellByColumnAndRow(7,$i)->getValue();
                $id_Employee = $sheetCurrent->getCellByColumnAndRow(8,$i)->getValue();
                $employee_Name = $sheetCurrent->getCellByColumnAndRow(9,$i)->getValue();

                $asset = new asset($asset_Label_Number,$asset_Description,$asset_Brand,$asset_Model,$asset_Sire,$asset_ValuesBooks,$asset_Condition,$asset_Class,$id_Employee,$employee_Name);
             
                $asset->setAsset_Label_Number($sheetCurrent->getCellByColumnAndRow(1,$i)->getValue());
                $asset->setAsset_Description($sheetCurrent->getCellByColumnAndRow(2,$i)->getValue());
                $asset->setAsset_Brand($sheetCurrent->getCellByColumnAndRow(3,$i)->getValue());
                $asset->setAsset_Model($sheetCurrent->getCellByColumnAndRow(4,$i)->getValue());

                //Apartir de aquí funcionaba
                 $asset->setAsset_Sire($sheetCurrent->getCellByColumnAndRow(5,$i)->getValue());
                 $asset->setAsset_ValuesBooks($sheetCurrent->getCellByColumnAndRow(6,$i)->getValue());
                 $asset->setAsset_Condition($sheetCurrent->getCellByColumnAndRow(7,$i)->getValue());
                 $asset->setAsset_Class($sheetCurrent->getCellByColumnAndRow(8,$i)->getValue());
                 $asset->setId_Employee($sheetCurrent->getCellByColumnAndRow(9,$i)->getValue());
                 $asset->setEmployee_Name($sheetCurrent->getCellByColumnAndRow(10,$i)->getValue());
                array_push($dataFile, $asset);
            }

            $assetBusiness = new cargararchivobusiness();
            $result = $assetBusiness->insertOrUpdate_Assets($dataFile);

            session_start();
            $_SESSION['dato_actualizado'] = true;

            if($result == 0){
                header("location: ../view/cargarexcelview.php?error=error");
            }else if($result == 1){
                header("location: ../view/cargarexcelview.php?success=updated");
            }else if($result == 2){
                header("location: ../view/cargarexcelview.php?success=inserted");    
            }
            
            else if($result == 3){
                header("location: ../view/cargarexcelview.php?success=no-updated");
            }
            
        } else {
            header("location: ../view/cargarexcelview.php?error=emptyField");
        }
    } else {
        header("location: ../view/cargarexcelview.php?error=error");
    }
}

 