<?php

include './employeebusiness.php';
include './util.php';
session_start();

if (isset($_POST['update'])) {

    if (
        isset($_POST['employeeid']) && isset($_POST['employeeidentification']) && isset($_POST['employeename'])
        && isset($_POST['employeelastname']) && isset($_POST['employeephone']) && isset($_POST['employeeemail'])
        && isset($_POST['employeepassword'])
    ) {

        $employeeId = $_POST['employeeid'];
        $employeeIdentification = $_POST['employeeidentification'];
        $employeeName = $_POST['employeename'];
        $employeeLastName = $_POST['employeelastname'];
        $employeePhone = $_POST['employeephone'];
        $employeeEmail = $_POST['employeeemail'];
        $employeePassword = $_POST['employeepassword'];
        $employeeActive = isset($_POST['employeeactive']) ? 1 : 0; //if the checkbox is checked, the value is 1, otherwise 0

        if (
            strlen($employeeId) > 0 && strlen($employeeIdentification) > 0 && strlen($employeeName) > 0 &&
            strlen($employeeLastName) > 0
            && strlen($employeePhone) > 0 && strlen($employeeEmail) > 0 && strlen($employeePassword) > 0
        ) {
            $employee = new Employee(
                $employeeId,
                $employeeIdentification,
                $employeeName,
                $employeeLastName,
                $employeePhone,
                $employeeEmail,
                $employeePassword,
                $employeeActive,
                $employeePhoto
            );

            $employeeBusiness = new EmployeeBusiness();
            $result = $employeeBusiness->updateTBEmployee($employee);
            if ($result == 1) {
                header("location: ../view/employeeview.php?success=updated");
            } else {
                header("location: ../view/employeeview.php?error=dbError");
            }
        } else {
            header("location: ../view/employeeview.php?error=emptyField");
        }
    } else {
        header("location: ../view/employeeview.php?error=error");
    }
} else if (isset($_GET['delete'])) {
    $employeeId = $_GET['employeeid'];
    $employeeBusiness = new EmployeeBusiness();
    $result = $employeeBusiness->deleteTBEmployee($employeeId);
    // echo 'prueba' . $result;
    // exit();
    if ($result == 1) {
        // Verificar si el empleado eliminado es el mismo que está en sesión
        // echo "Session employeeid: " . $_SESSION['employeeid'];
        // exit();
        if ($employeeId == $_SESSION['employeeid']) {
            // Destruir la sesión actual
            session_destroy();
            // Redireccionar al inicio de sesión u otra página adecuada después de cerrar sesión
            header("Location: ../view/login.php?success=delete");
            exit;
        }

        header("Location: ../view/users-profile.php?success=delete");
    } else {
        header("Location: ../view/users-profile.php?error=dbError");
    }
} else if (isset($_POST['create'])) {
    if (
        isset($_POST['employeeidentification']) && isset($_POST['employeename'])
        && isset($_POST['employeelastname']) && isset($_POST['employeephone']) && isset($_POST['employeeemail'])
        && isset($_POST['employeepassword'])
    ) {
        $employeeIdentification = $_POST['employeeidentification'];
        $employeeName = $_POST['employeename'];
        $employeeLastName = $_POST['employeelastname'];
        $employeePhone = $_POST['employeephone'];
        $employeeEmail = $_POST['employeeemail'];
        $employeePassword = password_hash($_POST['employeepassword'], PASSWORD_DEFAULT);
        $employeeActive = 1;

        // Check if the file was uploaded successfully
        if (isset($_FILES['employeephoto']) && $_FILES['employeephoto']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = '../employeephotos/'; // Directorio para guardar las fotos de los empleados
            // Directory to upload the photos
            $photoName = $_FILES['employeephoto']['name'];
            $photoTmpName = $_FILES['employeephoto']['tmp_name'];
            $photoPath = $uploadDir . $photoName;
            move_uploaded_file($photoTmpName, $photoPath); // Move the uploaded photo to the designated directory

            $employeePhoto = $photoPath;
        } else {
            $employeePhoto = null;
        }

        if (
            strlen($employeeIdentification) > 0 && strlen($employeeName) > 0 && strlen($employeeLastName) > 0
            && strlen($employeePhone) > 0 && strlen($employeeEmail) > 0 && strlen($employeePassword) > 0
        ) {
            $employee = new Employee(
                0,
                $employeeIdentification,
                $employeeName,
                $employeeLastName,
                $employeePhone,
                $employeeEmail,
                $employeePassword,
                $employeeActive,
                $employeePhoto
            );

            // Generate a code to reset the password if forgotten
            $generateRandomString = Util::generateRandomString(12);
            $passwordForgotIdentity = Util::generatePasswordForgotIdentity($generateRandomString);

            $employeeBusiness = new EmployeeBusiness();

            $result = $employeeBusiness->insertTBEmployee($employee, $passwordForgotIdentity);

            if ($result == 1) {
                header("location: ../view/users-profile.php?success=inserted");
            } else {
                header("location: ../view/users-profile.php?error=dbError");
            }
        } else {
            header("location: ../view/users-profile.php?error=emptyField");
        }
    } else {
        header("location: ../view/users-profile.php?error=error");
    }
} else if (isset($_POST['action']) && strcmp($_POST['action'], 'change-password') == 0) {
    if (isset($_POST['identification']) && isset($_POST['passwordactual']) && isset($_POST['password']) && isset($_POST['passwordc'])) {
        $employeeBusiness = new EmployeeBusiness();
        if ($employeeBusiness->getPassword(trim($_POST['identification']), trim($_POST['passwordactual']))) {
            if (strcmp(trim($_POST['password']), trim($_POST['passwordc'])) == 0) {
                if ($employeeBusiness->setPassword(trim($_POST['password']), trim($_POST['identification']))) {
                    echo json_encode(['success' => 'changedpassword']);
                } else {
                    echo json_encode(['error' => 'notchangedpassword']);
                }
            } else {
                echo json_encode(['error' => 'passwordverify']);
            }
        } else {
            echo json_encode(['error' => 'validatecurrentpassword']);
        }
    }
}
