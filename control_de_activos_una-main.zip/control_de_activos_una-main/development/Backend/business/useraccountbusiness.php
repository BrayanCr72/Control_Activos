<?php

include '../data/userdata.php';

class UserAccountBusiness
{

    private $userData;

    public function __construct()
    {
        $this->userData = new UserData();
    }

    public function getRow($username_email, $password)
    {
        return $this->userData->getRow($username_email, $password);
    }

    ////////////////////////////////////////////
    public function getRowPrueba($username_email, $password)
    {
        return $this->userData->getRowPrueba($username_email, $password);
    }
    /////////////////////////////////////////////
    public function verifyEmail($email)
    {

        return $this->userData->verifyEmail($email);
    }

    public function updateForgotPasswordIdentity($pass_identity, $modifiedDate, $email)
    {
        return $this->userData->updateForgotPasswordIdentity($pass_identity, $modifiedDate, $email);
    }

    public function resetPassword($pass_identity, $password)
    {
        return $this->userData->resetPassword($pass_identity, $password);
    }

    public function getReactivateRow($username_email, $password)
    {
        return $this->userData->getReactivateRow($username_email, $password);
    }
}
