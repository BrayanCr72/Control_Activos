<?php

include_once('../data/assetdata.php');

class assetbusiness {

    private $assetData;
    
    public function __construct(){
        $this->assetData = new assetdata();
    }

    public function getAsset() {
        return $this->assetData->getAsset();
    }

    public function createFilterAsset() {
        return $this->assetData->createFilterAsset();
    }

     
  

    public function get_Asset() {
        return $this->assetData->getAsset();
    }

    public function insert_Asset($asset) {
        return $this->assetData->insert_Asset($asset);
    }
    
     


}