<?php

session_start();

include './useraccountbusiness.php';
include './util.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;


if (isset($_POST['login'])) {

    if (!empty($_POST['username_email']) && !empty($_POST['password'])) {

        $userBusiness = new UserAccountBusiness();

        //$hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $userData = $userBusiness->getRow($_POST['username_email'], $_POST['password']);
        /* var_dump($userData); */
        // $userData = $userBusiness->getRowPrueba($_POST['username_email'],$hash );
        if ($userData == 1) {
            header("Location: ../index.php");
        } else {

            $sessData['status']['type'] = 'error';
            $sessData['status']['msg'] = 'Correo electrónico o contraseña incorrectos, intente nuevamente.';

            $_SESSION['sessData'] = $sessData;
            header("Location: ../view/login.php");
            exit;
        }
    } else {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'Ingrese correo electrónico y contraseña.';

        $_SESSION['sessData'] = $sessData;
        header("Location: ../view/login.php");
    }
} else if (isset($_POST['forgotSubmit'])) {

    if (!empty($_POST['email'])) {

        $userBusiness = new UserAccountBusiness();

        $resultquery = $userBusiness->verifyEmail($_POST['email']);

        if (!empty($resultquery)) {

            $generateRandomString = Util::generateRandomString(12);
            $passwordForgotIdentity = Util::generatePasswordForgotIdentity($generateRandomString);

            // ? Actualizar el forgot_pass_identity
            $updated = $userBusiness->updateForgotPasswordIdentity($passwordForgotIdentity, date("Y-m-d H:i:s"), $resultquery['employeeemail']);

            if ($updated) {

                $resetPassLink = 'http://localhost/control_de_activos_una/development/backend/view/resetPassword.php?fp_code=' . $passwordForgotIdentity;

                /* --------------- Envio de correo para restablecer el password--------------- */
                require '../mailer/src/PHPMailer.php';
                require '../mailer/src/Exception.php';
                require '../mailer/src/SMTP.php';

                $mail = new PHPMailer(true);

                try {
                    // Configura el servidor SMTP
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'pedrovr81999@gmail.com';
                    $mail->Password   = 'usixqtemtztlszfi';
                    $mail->SMTPSecure =  PHPMailer::ENCRYPTION_STARTTLS; //'tls';
                    $mail->Port       =  587;

                    // Configura los destinatarios, el asunto y el contenido del correo
                    $mail->setFrom('pedrovr81999@gmail.com', 'pedro');
                    $mail->addAddress($resultquery['employeeemail'], $resultquery['first_name']);
                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8';
                    $mail->Subject = 'Solicitud de Cambio de Contraseña';
                    $mail->Body    = '
                    <!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta http-equiv="X-UA-Compatible" content="IE=edge">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title></title>
                            <style>
                                *{
                                    margin: 0;
                                    padding: 0;
                                }
                                #container{
                                    padding: 8px;
                                    background-color: #E8EEF2;
                                    border-radius: 5px;
                                }

                                #get-reset:hover{
                                    color: #EF705A;
                                }
                            </style>
                        </head>
                        <body>
                            <div id="container">
                                                                <h1>Reestablecer Contraseña</h1>
                                                                <p>Estimad@ <b>' . $resultquery['first_name'] . '</b></p><br>
                                                                <span>Recientemente se envió una solicitud para restablecer una contraseña para su cuenta.
                                                                Si esto fue un error, simplemente ignore este correo electrónico y no pasará nada.</span>                                                     
                                                                <br><span>Para restablecer su contraseña, visite el siguiente enlace: <a id="get-reset" href="' . $resetPassLink . '">' . $resetPassLink . '</a></span>
                                                                <br><em>Saludos!!</em>
                                </div>
                        </body>
                        </html>
                ';

                    if ($mail->send()) {

                        $sessData['status']['type'] = 'success';
                        $sessData['status']['msg'] = 'Verifique su correo electrónico, hemos enviado un enlace para restablecer la contraseña a su correo electrónico registrado.';

                        $_SESSION['sessData'] = $sessData;
                        header("Location: ../view/forgotpassword.php");
                    } else {
                        echo 'error al enviar!';
                        $sessData['status']['type'] = 'error';
                        $sessData['status']['msg'] = 'Se produjo un error al enviar el email.';

                        $_SESSION['sessData'] = $sessData;
                        header("Location: ../view/forgotpassword.php");
                    }
                } catch (Exception $e) {
                    echo 'error';
                }

                /* -------------------------------------------------------*/
            } else {

                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Se produjo algún problema, por favor intente nuevamente.';

                $_SESSION['sessData'] = $sessData;
                header("Location: ../view/forgotpassword.php");
            }
        } else {

            $sessData['status']['type'] = 'error';
            $sessData['status']['msg'] = 'El correo electrónico dado no está asociado con ninguna cuenta.';

            $_SESSION['sessData'] = $sessData;
            header("Location: ../view/forgotpassword.php");
        }
    } else {

        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'Ingrese el correo electrónico para crear una nueva contraseña para su cuenta.';
    }
} else if (isset($_POST['resetSubmit'])) {

    if (!empty($_POST['password']) && !empty($_POST['confirm_password']) && !empty($_POST['fp_code'])) {

        //contraseña y confirmar comparación de contraseña
        if ($_POST['password'] !== $_POST['confirm_password']) {

            $sessData['status']['type'] = 'error';
            $sessData['status']['msg'] = 'Confirme que la contraseña deben coincidir.';

            $_SESSION['sessData'] = $sessData;
            header("Location: ../view/resetPassword.php");
        } else {

            $userBusiness = new UserAccountBusiness();
            // ? se resetea con el hash por lo que si no existe no se podra realizar
            $updatedpassword = $userBusiness->resetPassword($_POST['fp_code'], password_hash($_POST['password'], PASSWORD_DEFAULT));

            if ($updatedpassword) {

                $sessData['status']['type'] = 'success';
                $sessData['status']['msg'] = 'La contraseña de su cuenta se ha restablecido correctamente. Inicia sesión con tu nueva contraseña.';

                $_SESSION['sessData'] = $sessData;
                header("Location: ../view/resetPassword.php");
            } else {

                $sessData['status']['type'] = 'error';
                $sessData['status']['msg'] = 'Se produjo algún problema, por favor intente nuevamente.';

                $_SESSION['sessData'] = $sessData;
                header("Location: ../view/resetPassword.php");
            }
        }
    }
} else if (isset($_POST['login'])) {

    if (isset($_POST['username_email']) && isset($_POST['password'])) {


        $passwordEncripted = $_POST['password'];
        $usser = $_POST['username_email'];


        if (strlen($usser) > 0 && strlen($passwordEncripted) > 0) {

            $usserBusiness = new useraccountbusiness();
            $result = $usserBusiness->getRowPrueba($usser, $passwordEncripted);

            if ($result == 1) {

                header("Location: ../index.php?success=login");
            } else {

                header("Location: ../view/login.php?error=login");
            }
        } else {
            header("Location: ../view/login.php?error=emptyFiled");
        }
    } else {
        header("Location: ../view/login.php?error=error");
    }
} else if (isset($_POST['reactivate'])) {
    if (!empty($_POST['username_email']) && !empty($_POST['password'])) {
        $userBusiness = new UserAccountBusiness();
        $userData = $userBusiness->getReactivateRow($_POST['username_email'], $_POST['password']);

        if ($userData['status'] === 'accountActive') {
            // La cuenta del empleado ya está activa, mostrar un mensaje de error o redirigir a una página de error
            header("Location: ../view/reactivateAccount.php?error=accountActive");
            exit;
        } elseif ($userData['status'] === 'incorrectPassword') {
            // Contraseña incorrecta, mostrar un mensaje de error o redirigir a una página de error
            header("Location: ../view/reactivateAccount.php?error=incorrectPassword");
            exit;
        } elseif ($userData['status'] === 'userNotFound') {
            // No se encontró el usuario o correo, mostrar un mensaje de error o redirigir a una página de error
            header("Location: ../view/reactivateAccount.php?error=userNotFound");
            exit;
        } else {
            session_start();
            $_SESSION['employeeid'] = $userData['employeeid'];
            $_SESSION['employee_id'] = $userData['employeeid'];
            $_SESSION['employeename'] = $userData['employeename'];
            $_SESSION['id2'] = $userData['employeeidentification'];
            $_SESSION['employeelastname'] = $userData['employeelastname'];
            $_SESSION['employeephone'] = $userData['employeephone'];
            $_SESSION['employeeemail'] = $userData['employeeemail'];
            $_SESSION['employeephoto'] = $userData['employeephoto'];

            header("Location: ../index.php");
            exit;
        }
    } else {
        $sessData['status']['type'] = 'error';
        $sessData['status']['msg'] = 'Ingrese correo electrónico y contraseña.';
    }

    $_SESSION['sessData'] = $sessData;
    header("Location: ../view/reactivateAccount.php");
    exit;
}
