<?php

class Util{

    // Generar una cadena aleatoria de caracteres
    public static function generateRandomString($length = 10)
    {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    public static function generatePasswordForgotIdentity($generateRandomString)
    {
        // Generar una contraseña única
        $randomPassword = $generateRandomString; // Genera una cadena aleatoria de longitud 12
        // Identificador único, como un timestamp
        $uniqueIdentifier = time(); // Puedes usar otra fuente de identificación única si lo prefieres
        // Combinar la contraseña y el identificador único
        $combinedData = $randomPassword . $uniqueIdentifier;
        // Generar el hash de la combinación
        $hashedPassword = password_hash($combinedData, PASSWORD_DEFAULT);
        return $hashedPassword;
    }
}