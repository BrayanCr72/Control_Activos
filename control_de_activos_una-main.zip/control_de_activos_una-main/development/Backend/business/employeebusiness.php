<?php

include '../data/employeedata.php';

class EmployeeBusiness{

    private $employee_Data;

    public function __construct(){//constructor
        $this->employee_Data = new EmployeeData();
    }

    public function insertTBEmployee($employee,$generatePasswordForgotIdentity){//inserts a new employee
        return $this->employee_Data->insertTBEmployee($employee, $generatePasswordForgotIdentity);//calls the function insertTBEmployee 
        //from employeedata.php and returns the result of that function 
    }

    public function updateTBEmployee($employee){
        return $this->employee_Data->updateTBEmployee($employee);//calls the function updateTBEmployee 
    }

    public function deleteTBEmployee($employee){//deletes an employee
        return $this->employee_Data->deleteTBEmployee($employee);//calls the function deleteTBEmployee
    }

    public function getAllTBEmployee(){
        return $this->employee_Data->getAllTBEmployee();//calls the function getAllTBEmployee
    }
    public function getTBEmployeeById($employee){//deletes an employee
        return $this->employee_Data->getTBEmployeeById($employee);//calls the function deleteTBEmployee
    }
    // ? [-------los ultimos que se agregaron----------]
    public function getPassword($identification,$currentpassword){
        return $this->employee_Data->getPassword($identification,$currentpassword);
    }

    public function setPassword($password,$identification){
        return $this->employee_Data->setPassword($password,$identification);
    }
}

