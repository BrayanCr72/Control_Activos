<?php

include_once('../data/assetdata.php');

class cargararchivobusiness {

    private $assetData;


    public function __construct(){
        $this->assetData = new assetdata();
    }

    public function insertOrUpdate_Assets($asset) {
        return $this->assetData->insertOrUpdate_Assets($asset);
    }
    
}