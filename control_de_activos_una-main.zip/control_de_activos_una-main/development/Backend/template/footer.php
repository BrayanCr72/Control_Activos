    
    <?php 
        require_once ("../config/config.php");
    ?>
    
    
    <script src="<?= BASE_URL ?>Activos/development/Backend/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="<?= BASE_URL ?>Activos/development/Backend/js/functions.js"></script>
    
</body>
</html>