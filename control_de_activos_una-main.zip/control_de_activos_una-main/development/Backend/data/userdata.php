<?php

include_once 'data.php';
include '../domain/user.php';

class UserData extends Data
{
    // De Giancarlo, sirve para reactivar la cuenta del empleado
    public function getReactivateRow($username_email, $password)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $query = "SELECT * FROM tbemployee WHERE (employeename='$username_email' OR employeeemail='$username_email');";
        $result = mysqli_query($conn, $query);

        $queryGetId = "SELECT employeeid FROM tbemployee WHERE (employeename='$username_email' OR employeeemail='$username_email')";
        $resultId = mysqli_query($conn, $queryGetId);

        $row = null;
        $status = '';

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            $passuser = $row['employeepassword'];

            if (password_verify($password, $passuser)) {
                if ($row['employeeactive'] == 0) {
                    // Reactivar la cuenta del empleado
                    $updateQuery = "UPDATE tbemployee SET employeeactive = 1 WHERE employeeid = " . $row['employeeid'];
                    mysqli_query($conn, $updateQuery);

                    $status = 'accountReactivated';
                } else {
                    // La cuenta del empleado ya está activa
                    $status = 'accountActive';
                }
            } else {
                // Contraseña incorrecta
                $status = 'incorrectPassword';
            }
        } else {
            // No se encontró el usuario o correo
            $status = 'userNotFound';
        }

        return [
            'status' => $status,
            'employeeid' => $row['employeeid'],
            'employeename' => $row['employeename'],
            'employeeidentification' => $row['employeeidentification'],
            'employeelastname' => $row['employeelastname'],
            'employeephone' => $row['employeephone'],
            'employeeemail' => $row['employeeemail'],
            'employeephoto' => $row['employeephoto']
        ];
    }

    // De Pedro arreglado por Giancarlo
    public function getRow($username_email, $password)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $query = "SELECT * FROM tbemployee WHERE (employeename='$username_email' OR employeeemail='$username_email');";
        $result = mysqli_query($conn, $query);

        $queryGetId = "SELECT employeeid FROM tbemployee WHERE (employeename='$username_email' OR employeeemail='$username_email')";
        $resultId = mysqli_query($conn, $queryGetId);

        $sesion = 0;
        $row = null;

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            $passuser = $row['employeepassword'];

            if (password_verify($password, $passuser)) {
                if ($row['employeeactive'] == 0) { // Verificar si la cuenta del empleado está desactivada
                    // La cuenta del empleado está desactivada, mostrar un mensaje de error o redirigir a una página de error
                    header("Location: ../view/login.php?error=inactiveAccount");
                    exit;
                }

                session_start();
                $resultIdRow = mysqli_fetch_assoc($resultId);
                $_SESSION['employeeid'] = $resultIdRow['employeeid'];
                $_SESSION['employee_id'] = $resultIdRow['employeeid'];
                $_SESSION['employeename'] = $row['employeename'];
                $_SESSION['id2'] = $row['employeeidentification'];
                $_SESSION['employeelastname'] = $row['employeelastname'];
                $_SESSION['employeephone'] = $row['employeephone'];
                $_SESSION['employeeemail'] = $row['employeeemail'];
                $_SESSION['employeephoto'] = $row['employeephoto'];
                $sesion = 1;
            } else {
                $sesion = 0;
            }
        }

        return $sesion;
    }


    // De Ordoñez
    // public function getRowPrueba($username_email, $password)
    // {
    //     $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
    //     $conn->set_charset('utf8');

    //     // Convertir la contraseña ingresada a hash MD5

    //     $query = "SELECT * FROM tbemployee WHERE (employeename='$username_email' 
    //     OR employeeemail='$username_email');";
    //     $result = mysqli_query($conn, $query);
    //     mysqli_close($conn);

    //     // Inicializar la variable $row
    //     $sesion = 0;


    //     while ($row = mysqli_fetch_array($result)) {
    //         $passuser = $row['employeepassword'];

    //         if (password_verify($password, $passuser)) {

    //             session_Start();
    //             $_SESSION['employeeid'] = $row['employeeid'];
    //             $_SESSION['id'] = $row['employeename'];
    //             $_SESSION['id2'] = $row['employeeidentification'];
    //             $_SESSION['employeelastname'] = $row['employeelastname'];
    //             $_SESSION['employeephone'] = $row['employeephone'];
    //             $_SESSION['employeeemail'] = $row['employeeemail'];
    //             $_SESSION['employeephoto'] = $row['employeephoto']; // Agregar el dato de la foto a la sesión
    //             $sesion = 1;
    //         } else {


    //             $sesion = 0;
    //         }
    //     }
    //     return $sesion;
    // }
    // ! Validar email
    public function verifyEmail($email)
    {

        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        // Consulta para verificar si el correo electrónico ya está registrado en la tabla
        $sql = "SELECT * FROM tbemployee WHERE employeeemail = '$email'";
        $result = mysqli_query($conn, $sql);

        $row = null;

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
        }
        return $row;
    }

    // ! Actualizar el hash de forgot_pass_indentity

    public function updateForgotPasswordIdentity($pass_identity, $modifiedDate, $email)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        // Definir la consulta preparada
        $stmt = mysqli_prepare($conn, "UPDATE tbemployee SET forgotpassidentity=?, modified=? WHERE employeeemail=?");

        // Vincular los parámetros de la consulta preparada con las variables
        mysqli_stmt_bind_param($stmt, 'sss', $pass_identity, $modifiedDate, $email);

        // Ejecutar la consulta preparada
        $result = mysqli_stmt_execute($stmt);

        // Verificar si la consulta se ejecutó correctamente
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function resetPassword($pass_identity, $password)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $stmt = mysqli_prepare($conn, "SELECT * FROM tbemployee WHERE forgotpassidentity = ?");
        mysqli_stmt_bind_param($stmt, 's', $pass_identity);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {

            $stmt = mysqli_prepare($conn, "UPDATE tbemployee SET employeepassword=? WHERE forgotpassidentity=?");
            mysqli_stmt_bind_param($stmt, 'ss', $password, $pass_identity);
            $result = mysqli_stmt_execute($stmt);

            if ($result) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
