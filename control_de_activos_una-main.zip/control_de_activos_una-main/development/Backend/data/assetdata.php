<?php
include_once('data.php');
include_once('../domain/asset.php');



class assetdata extends data
{

    public function getAsset()
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $querySelect = "SELECT * FROM tbasset";
        $result = mysqli_query($conn, $querySelect);
        mysqli_close($conn);
        $assets = [];
        while ($row = mysqli_fetch_array($result)) {
            $currentAsset = new asset(
                $row['AssetLabelNumber'],
                $row['AssetDescription'],
                $row['AssetBrand'],
                $row['AssetModel'],
                $row['AssetSire'],
                $row['ValuesBooks'],
                $row['AssetCondition'],
                $row['AssetClass'],
                $row['IdEmployee'],
                $row['EmployeeName']
            );
            array_push($assets, $currentAsset);
        }
        return $assets;
    }


    //Method to create the filter.
    public function createFilterAsset()
    {



        if ($_POST['buscar'] == '') {
            $_POST['buscar'] = ' ';
        }
        $keyWord = explode(" ", $_POST['buscar']);



        if ($_POST["buscar"] == '' and $_POST['identificadoractivo'] == '' and $_POST['nombrefuncionario'] == '' and $_POST['valorenlibrosdesde'] == '' and $_POST['valorenlibroshasta'] == '' and $_POST['condicion'] == '') {
            $query = "SELECT * FROM tbasset ";
        } else {


            $query = "SELECT * FROM tbasset ";

            if ($_POST["buscar"] != '') {

                $query .= "WHERE (AssetClass LIKE LOWER('%" . $keyWord[0] . "%') OR IdAsset  LIKE LOWER('%" . $keyWord[0] . "%') OR AssetDescription LIKE LOWER('%" . $keyWord[0] . "%') OR AssetBrand LIKE LOWER('%" . $keyWord[0] . "%')  OR AssetModel LIKE LOWER('%" . $keyWord[0] . "%')  OR AssetSire LIKE LOWER('%" . $keyWord[0] . "%')
               OR ValuesBooks LIKE LOWER('%" . $keyWord[0] . "%')  OR AssetCondition LIKE LOWER('%" . $keyWord[0] . "%') OR IdEmployee LIKE LOWER('%" . $keyWord[0] . "%') OR EmployeeName LIKE LOWER('%" . $keyWord[0] . "%')) ";


                for ($i = 1; $i < count($keyWord); $i++) {
                    if (!empty($keyWord[$i])) {
                        $query .= " OR AssetClass LIKE '%" . $keyWord[$i] . "%' OR IdAsset  LIKE '%" . $keyWord[$i] . "%' OR AssetDescription LIKE '%" . $keyWord[$i] . "%' OR AssetBrand LIKE '%" . $keyWord[$i] . "%' OR AssetModel LIKE '%" . $keyWord[$i] . "%'  OR AssetSire LIKE '%" . $keyWord[$i]
                            . "%' OR ValuesBooks LIKE '%" . $keyWord[$i] . "%' OR AssetCondition LIKE '%" . $keyWord[$i] . "%' OR IdEmployee LIKE '%" . $keyWord[$i] . "%' OR EmployeeName LIKE '%" . $keyWord[$i] . "%'";
                    }
                }
            }
        }
        ///

        //The filter by EmployeeName is created
        $keyWord = explode(" ", $_POST['nombrefuncionario']);
        if ($_POST['nombrefuncionario']) {
            $query = "SELECT * FROM tbasset ";



            if ($_POST["nombrefuncionario"] != '') {
                $query .= "WHERE (EmployeeName LIKE LOWER('%" . $keyWord[0] . "%')) ";

                for ($i = 1; $i < count($keyWord); $i++) {
                    if (!empty($keyWord[$i])) {
                        $query .= " OR EmployeeName LIKE '%" . $keyWord[$i] . "%' OR apellidos LIKE '%" . $keyWord[$i] . "%'";
                    }
                }
            }
        }

        //The filter by IdAsset  is created.
        /*if ( $_POST['identificadoractivo'] != '' ){   
            $IdAssetValid = filter_var($_POST['identificadoractivo'],FILTER_VALIDATE_INT);
            $query .= " AND IdAsset  >= '".$IdAssetValid."' ";
        }
        */


        //The filter by ValuesBooks is created
        if ($_POST['valorenlibrosdesde'] != '') {
            $query .= " AND ValuesBooks >= '" . $_POST['valorenlibrosdesde'] . "' ";
        }
        //The filter by ValuesBooks is created.
        if ($_POST['valorenlibroshasta'] != '') {
            $query .= " AND ValuesBooks <= '" . $_POST['valorenlibroshasta'] . "' ";
        }
        //The filter by ValuesBooks is created
        if ($_POST["condicion"] != '') {
            $query .= " AND AssetCondition = '" . $_POST["condicion"] . "' ";
        }

        return $query;
    }

    function MuestraAlert()
    {
        swal("Titulo", "Prueba", "success");
    }

    //method to insert an asset
    public function insertOrUpdate_Assets($asset)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $resultado = 0;
    
        if (!$conn) {
            throw new Exception("Error al conectarse a la base de datos: " . mysqli_connect_error());
        }
    
        $cont = 0;
        $cont1 = 0;
        $cont2 = 0;
        $conn->set_charset('utf8');
    
        try {
            foreach ($asset as $objeto) {
                $cont++;
    
                // Verificar duplicados
                $query = "SELECT * FROM tbasset WHERE AssetLabelNumber = '" . $objeto->getAsset_Label_Number() . "'";
                $result = $conn->query($query);
    
                if ($result) {
                    
                    $count = $result->num_rows;
                    if ($count > 0) {
                         
                        // Actualizar registro existente si algún dato ha cambiado
                        $row = $result->fetch_assoc();
    
    
                        $AssetDescription = $objeto->getAsset_Description();
                        $AssetBrand = $objeto->getAsset_Brand();
                        $AssetModel = $objeto->getAsset_Model();
                        $asset_Sire = $objeto->getAsset_Sire();
                        $asset_ValuesBooks = $objeto->getAsset_ValuesBooks();
                        $asset_Condition = $objeto->getAsset_Condition();
                        $asset_Class = $objeto->getAsset_Class();
                        $id_Employee = $objeto->getId_Employee();
                        $employee_Name = $objeto->getEmployee_Name();
                        $AsseLabelNumber = $row["AssetLabelNumber"];
                
                        $stmt = $conn->prepare("UPDATE `tbasset` SET `AssetDescription`= ?,`AssetBrand`= ?,`AssetModel`= ?,`AssetSire`= ?,`AssetCondition`= ?,`ValuesBooks`= ?,`AssetClass`= ?,`IdEmployee`= ?,`EmployeeName`= ? WHERE `AssetLabelNumber` = ?");
                        $stmt->bind_param("sssssdssis",$AssetDescription,$AssetBrand,$AssetModel,$asset_Sire,$asset_ValuesBooks,$asset_Condition,$asset_Class,$id_Employee,$employee_Name,$AsseLabelNumber); 
                        $stmt->execute();
                        $filas = $stmt->affected_rows;
    
                        if($filas > 0 ){
                           $resultado = 1;
                              
                        }else{
                            $resultado=3;  
                        }
    
                        continue; // Pasar al siguiente objeto sin insertar ni contar como duplicado
                    }
                } else {
                    // echo "Error al verificar duplicados: " . $conn->error;
                    continue; // Pasar al siguiente objeto sin insertar
                }
    
                // Insertar registro
                 $insertQuery = "INSERT INTO tbasset (AssetLabelNumber, AssetDescription, AssetBrand, AssetModel,AssetSire,ValuesBooks,AssetCondition,AssetClass,IdEmployee,EmployeeName) VALUES ('" . $objeto->getAsset_Label_Number() . "', '" . $objeto->getAsset_Description() . "', '" . $objeto->getAsset_Brand() . "', '" . $objeto->getAsset_Model() . "', '" . $objeto->getAsset_Sire() . "', '" . $objeto->getAsset_ValuesBooks() . "', '" . $objeto->getAsset_Condition() . "', '" . $objeto->getAsset_Class() . "', '" . $objeto->getId_Employee() . "', '" . $objeto->getEmployee_Name() . "')";
    
                if ($conn->query($insertQuery) === TRUE) {
                    $resultado=2;
                    $cont1++;
                    
                 } 
            }
    
        } catch (Exception $e) {
            mysqli_close($conn);
            throw new Exception($e->getMessage());
        }
        return $resultado;
    }

    //Luis


    //Comparara los datos de la base de datos con la información del nuevo archivo.
    public function compareWithDataBase($dataFile) {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');
        // Conexión a la base de datos (debes tener tu propia lógica de conexión)
    
        // Recorre los datos del archivo y realiza la comparación con los datos en la base de datos
        foreach ($dataFile as $asset) {
            $AssetLabelNumber = $asset->getLabelNumber();
            $AssetSire = $asset->getSerial();
    
            // Realiza una consulta para verificar si el asset_Label_Number y asset_Serial existen en la base de datos
            $query = "SELECT COUNT(*) AS count FROM tbasset WHERE AssetLabelNumber = '$AssetLabelNumber' AND AssetSire = '$AssetSire'";
            $result = mysqli_query($connection, $query);
    
            // Verifica el resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            $count = $row['count'];
    
            // Si count es mayor a cero, significa que el registro ya existe en la base de datos
            if ($count > 0) {
                return true; // Existe una coincidencia, se debe generar una alerta
            }
        }
    
        return false; // No se encontraron coincidencias en la base de datos
    }
 
    public function getAssetByName($value)
    {

        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $querySelect = "SELECT * FROM tbasset WHERE EmployeeName LIKE '%$value%'";

        $result = mysqli_query($conn, $querySelect);
        mysqli_close($conn);
        $assets = [];
        while ($row = mysqli_fetch_array($result)) {
            $currentAsset = new asset(
                $row['AssetLabelNumber'],
                $row['AssetDescription'],
                $row['AssetBrand'],
                $row['AssetModel'],
                $row['AssetSire'],
                $row['ValuesBooks'],
                $row['AssetCondition'],
                $row['AssetClass'],
                $row['IdEmployee'],
                $row['EmployeeName']
            );
            array_push($assets, $currentAsset);
        }
        return $assets;
    }
    public function addObservation($assetid, $observation)
    {

        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $queryUpdate = "UPDATE tbasset SET Observation = '$observation' WHERE AssetLabelNumber = '$assetid'";
        // Ejecutar la consulta SQL
        $resultado = mysqli_query($conn, $queryUpdate);
        // Verificar si la actualización se realizó correctamente
        $response = '';
        if (mysqli_affected_rows($conn) > 0) {
            $response = "La observación se realizó correctamente.";
        } else {
            $response = "No se pudo realizar la observación.";
        }
        // Cerrar la conexión a la base de datos
        mysqli_close($conn);
        return $response;
    }
}