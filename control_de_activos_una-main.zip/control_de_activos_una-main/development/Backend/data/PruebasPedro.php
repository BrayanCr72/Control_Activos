<?php
require_once 'employeedata.php';

use PHPUnit\Framework\TestCase;

class PruebasPedro extends TestCase
{
    protected $employee;


    public function setUp(): void
    {
        parent::setUp();
        $this->employee = new employeedata();
    }

    public function testGetAllTBEmployee()
    {
        $resultado = $this->employee->getAllTBEmployee();
        $this->assertIsArray($resultado);
        $this->assertNotEmpty($resultado);
    }

    public function testGetAllTBEmployeeById()
    {
        $resultado = $this->employee->getTBEmployeeById(2);
        $this->assertNotEmpty($resultado);
    }

    public function testInsertTBEmployee()
    {
        $objEmployee = new Employee(4, "4-0322-0332", "Juan", "Hernandez",
        "34545433", "juan@est.una.ac.cr", "123456789", 1, "no tiene");
        $result = $this->employee->insertTBEmployee($objEmployee, "322332");
        $this->assertTrue($result);
    }

    public function testEditTBEmployee()
    {
        $objEmployee = new Employee(4, "4-0322-0332", "Juan", "Hernandez",
        "34545433", "juan@est.una.ac.cr", "123456789", 1, "no tiene");
        $result = $this->employee->updateTBEmployee($objEmployee);
        $this->assertTrue($result);
    }

    public function testDeleteTBEmployee()
    {
        $result = $this->employee->deleteTBEmployee(4);
        $this->assertTrue($result);
    }




    
}