<?php

include_once 'data.php';
include '../domain/employee.php';
//generatePasswordForgotIdentity
class EmployeeData extends Data
{ //this class inherits from Data class 

    public function insertTBEmployee($employee, $generatePasswordForgotIdentity)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $queryGetLastId = "SELECT MAX(employeeid) AS employeeid FROM tbemployee";
        $idCont = mysqli_query($conn, $queryGetLastId);
        $nextId = 1;

        if ($row = mysqli_fetch_row($idCont)) {
            $nextId = $row[0] + 1;
        }

        $queryInsert = "INSERT INTO tbemployee VALUES (
            " . $nextId . ",
            '" . $employee->getEmployee_Identification() . "',
            '" . $employee->getEmployee_Name() . "',
            '" . $employee->getEmployee_LastName() . "',
            '" . $employee->getEmployee_Phone() . "',
            '" . $employee->getEmployee_Email() . "',
            '" . $employee->getEmployee_Password() . "',
            '" . $generatePasswordForgotIdentity . "',
            '" . date("Y-m-d H:i:s") . "',
            '-',
            " . $employee->getEmployee_Active() . ",
            '" . $employee->getEmployee_Photo() . "'
        )";

        $result = mysqli_query($conn, $queryInsert);
        mysqli_close($conn);
        return $result;
    }

    public function updateTBEmployee($employee)
    { //update an employee
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db); //connect to the database
        $conn->set_charset('utf8'); //set the charset to utf8

        //Update the employee
        $queryUpdate = "UPDATE tbemployee SET employeeidentification='" . $employee->getEmployee_Identification() .
            "', employeename='" . $employee->getEmployee_Name() .
            "', employeelastname='" . $employee->getEmployee_LastName() .
            "', employeephone='" . $employee->getEmployee_Phone() .
            "', employeeemail='" . $employee->getEmployee_Email() .
            "', employeepassword='" . $employee->getEmployee_Password() .
            "', employeeactive=" . $employee->getEmployee_Active() .
            " WHERE employeeid=" . $employee->getEmployee_Id() . ";";

        $result = mysqli_query($conn, $queryUpdate);
        mysqli_close($conn);

        return $result;
    }


    public function deleteTBEmployee($employeeId)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $queryUpdate = "UPDATE tbemployee SET employeeactive = 0 WHERE employeeid = " . $employeeId . ";";

        $result = mysqli_query($conn, $queryUpdate);
        mysqli_close($conn);
        return $result;
    }


    public function getAllTBEmployee()
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');
        $active = 1; //set the active variable to 1 to get only the active employees 
        $querySelect = "SELECT * FROM tbemployee WHERE employeeactive = $active"; //get all the active employees
        $result = mysqli_query($conn, $querySelect); //execute the query and get the result 
        mysqli_close($conn); //close the connection 
        $employees = []; //create an array to store the employees
        while ($row = mysqli_fetch_array($result)) { // while there are employees in the result 
            $currentEmployee = new Employee(
                $row['employeeid'],
                $row['employeeidentification'],
                $row['employeename'],
                $row['employeelastname'],
                $row['employeephone'],
                $row['employeeemail'],
                $row['employeepassword'],
                $row['employeeactive'],
                $row['employeephoto'] // Add the employeephoto field
            ); //create a new employee object
            array_push($employees, $currentEmployee); //add the employee to the array and repeat the process until there are no more employees
        }
        return $employees; //return the array with the employees
    }

    public function getTBEmployeeById($employeeId)
    {
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');

        $query = "SELECT * FROM tbemployee WHERE employeeid = $employeeId";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_assoc($result);

        // Verificar si se encontraron datos
        if ($row) {
            $employee = new Employee(
                $row['employeeid'],
                $row['employeeidentification'],
                $row['employeename'],
                $row['employeelastname'],
                $row['employeephone'],
                $row['employeeemail'],
                $row['employeepassword'],
                $row['employeeactive'],
                $row['employeephoto']
            );
        } else {
            $employee = null; // No se encontró ningún empleado con el ID dado
        }

        mysqli_close($conn);
        return $employee;
    }

    // ? Obtener contrasenia para poder cambiarlos en la vista del perfil
    public function getPassword($identification,$currentpassword){

        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');
        $query = "SELECT employeepassword FROM tbemployee WHERE employeeidentification = '$identification'";
        $resultado = mysqli_query($conn, $query);
        if($resultado){
            $row = mysqli_fetch_assoc($resultado);
            $password = $row['employeepassword'];
            if(password_verify($currentpassword,$password)){
                return true;
            }
        }
        return false;
    }

    // ? setear la contrasenia desde la vista del perfil
    public function setPassword($password,$identification){
        $conn = mysqli_connect($this->server, $this->user, $this->password, $this->db);
        $conn->set_charset('utf8');
        // ! encriptar la nueva contraseña
        $nuevaContrasenaEncriptada = password_hash($password, PASSWORD_DEFAULT);
        $query = "UPDATE tbemployee SET employeepassword = '$nuevaContrasenaEncriptada' WHERE employeeidentification = $identification";
        $resultado = mysqli_query($conn, $query);
        if($resultado) return true;
        return false;
    }
}
