<?php 

    const BASE_URL = "http://localhost/";
?>