from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

edge_driver_path = 'C:/Users/msi/Documents/Selenium/msedgedriver.exe'
driver = webdriver.Edge(executable_path=edge_driver_path)

driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')

driver.set_window_size(1552, 832)
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
driver.find_element(By.NAME, "login").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".bg-image").click()
time.sleep(0.3)
driver.find_element(By.LINK_TEXT, "Inicio").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "li:nth-child(3) > .dropdown-item > span").click()
time.sleep(1)
element = driver.find_element(By.XPATH, "//button[text()='Registro Funcionario']")
element.click()
time.sleep(1)

wait = WebDriverWait(driver, 10)
element = wait.until(EC.element_to_be_clickable((By.ID, "employeeemail")))
element.clear()

driver.find_element(By.ID, "employeeemail").send_keys("pepito@est.una.ac.cr")
time.sleep(0.3)
driver.find_element(By.ID, "employeepassword").clear()
driver.find_element(By.ID, "employeepassword").send_keys("12345678")
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".active:nth-child(1)").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeeidentification").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeeidentification").clear()
driver.find_element(By.ID, "employeeidentification").send_keys("1-0111-0222")
time.sleep(0.3)
driver.find_element(By.ID, "employeename").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeename").clear()
driver.find_element(By.ID, "employeename").send_keys("lala")
driver.find_element(By.ID, "registerForm").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeelastname").click()
driver.find_element(By.ID, "employeelastname").clear()
driver.find_element(By.ID, "employeelastname").send_keys("hernandez")
time.sleep(0.3)
driver.find_element(By.ID, "employeephone").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeephone").clear()
driver.find_element(By.ID, "employeephone").send_keys("(+506) 3454-6566")
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#registerForm > .row:nth-child(5) > .col-md-8").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeeemail").clear()
driver.find_element(By.ID, "employeeemail").send_keys("lala@est.una.ac.cr")
time.sleep(0.3)
driver.find_element(By.ID, "employeepassword").click()
time.sleep(0.3)
driver.find_element(By.ID, "employeepassword").click()
element = driver.find_element(By.ID, "employeepassword")
actions = ActionChains(driver)
time.sleep(0.3)
actions.double_click(element).perform()
driver.find_element(By.ID, "employeepassword").clear
driver.find_element(By.ID, "employeepassword").send_keys("123456789")
driver.find_element(By.NAME, "create").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
driver.find_element(By.CSS_SELECTOR, "li:nth-child(7) span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".swal2-confirm").click()
driver.find_element(By.NAME, "username_email").clear()
time.sleep(0.3)
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.CSS_SELECTOR, ".container > .row").click()

driver.quit()