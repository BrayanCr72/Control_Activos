from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select


edge_driver_path = 'C:/Users/msi/Documents/Selenium/msedgedriver.exe'
driver = webdriver.Edge(executable_path=edge_driver_path)

driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')
driver.set_window_size(1500, 800)
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
driver.find_element(By.NAME, "login").click()
time.sleep(1)
driver.find_element(By.LINK_TEXT, "Subir").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".nav-item:nth-child(2) > .collapsed > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".btn-primary").click()
time.sleep(1)
select_element = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "assetid")))
select_element.click()
time.sleep(1)
select = Select(select_element)
time.sleep(1)
driver.find_element(By.ID, "observation").click()
time.sleep(1)
driver.find_element(By.ID, "observation").click()
driver.find_element(By.ID, "observation").clear()
driver.find_element(By.ID, "observation").send_keys("no tiene")
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".btn-primary").click()
driver.find_element(By.ID, "condicion").click()
dropdown = driver.find_element(By.ID, "condicion")
dropdown.find_element(By.XPATH, "//option[. = 'En uso']").click()
driver.find_element(By.CSS_SELECTOR, ".col-1 > .btn").click()
driver.find_element(By.ID, "buscar").click()
driver.find_element(By.ID, "buscar").clear()
driver.find_element(By.ID, "buscar").send_keys("laptop")
time.sleep(0.3)
driver.find_element(By.ID, "buscar").send_keys(Keys.ENTER)
driver.find_element(By.ID, "buscar").click()
time.sleep(0.3)
driver.find_element(By.ID, "buscar").click()
element = driver.find_element(By.ID, "buscar")
time.sleep(0.3)
actions = ActionChains(driver)
actions.double_click(element).perform()
driver.find_element(By.ID, "buscar").clear()
driver.find_element(By.ID, "buscar").send_keys("pantalla")
driver.find_element(By.ID, "buscar").send_keys(Keys.ENTER)
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".fa-file-pdf").click()
driver.find_element(By.CSS_SELECTOR, ".table-responsive").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#sidebar-nav > .nav-item:nth-child(1) span").click()
driver.find_element(By.ID, "sidebar").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#sidebar-nav > .nav-item:nth-child(1) span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
time.sleep(0.3)
driver.find_element(By.LINK_TEXT, "Cerrar Sesión").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".swal2-confirm").click()
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
time.sleep(0.3)
driver.find_element(By.NAME, "password").clear()

driver.quit()