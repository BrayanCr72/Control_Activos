    from selenium import webdriver
    from selenium.webdriver.common.by import By
    import time
    import json
    from selenium.webdriver.common.action_chains import ActionChains
    from selenium.webdriver.support import expected_conditions
    from selenium.webdriver.support.wait import WebDriverWait
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    edge_driver_path = 'C:/Users/msi/Documents/Selenium/msedgedriver.exe'
    driver = webdriver.Edge(executable_path=edge_driver_path)

    driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')

    driver.set_window_size(1500, 800)
    time.sleep(0.3)
    driver.find_element(By.NAME, "username_email").clear()
    driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
    driver.find_element(By.NAME, "password").clear()
    driver.find_element(By.NAME, "password").send_keys("12345678")
    driver.find_element(By.NAME, "login").click()
    time.sleep(1)
    driver.find_element(By.CSS_SELECTOR, ".nav-item:nth-child(2) > .collapsed > span").click()
    time.sleep(0.3)
    driver.find_element(By.ID, "buscar").click()
    driver.find_element(By.ID, "buscar").clear()
    driver.find_element(By.ID, "buscar").send_keys("Computadora")
    time.sleep(0.3)
    driver.find_element(By.ID, "buscar").send_keys(Keys.ENTER)
    time.sleep(0.3)
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)

    driver.find_element(By.LINK_TEXT, "2").click()
    time.sleep(0.3)
    driver.find_element(By.LINK_TEXT, "3").click()
    time.sleep(0.3)
    driver.find_element(By.LINK_TEXT, "1").click()
    time.sleep(0.3)
    driver.execute_script("window.scrollTo(0, -document.body.scrollHeight);")
    time.sleep(0.5)
    driver.find_element(By.ID, "condicion").click()
    time.sleep(0.3)
    driver.execute_script("window.scrollTo(0, -document.body.scrollHeight);")
    time.sleep(0.5)
    dropdown = driver.find_element(By.ID, "condicion")
    time.sleep(0.3)
    dropdown.find_element(By.XPATH, "//option[. = 'En uso']").click()
    time.sleep(0.3)
    driver.find_element(By.CSS_SELECTOR, ".col-1 > .btn").click()
    time.sleep(0.3)
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)

    driver.find_element(By.LINK_TEXT, "2").click()
    time.sleep(0.3)
    driver.find_element(By.LINK_TEXT, "3").click()
    time.sleep(0.3)
    driver.find_element(By.CSS_SELECTOR, "#sidebar-nav > .nav-item:nth-child(1) span").click()
    time.sleep(0.3)
    driver.find_element(By.CSS_SELECTOR, ".d-none").click()
    time.sleep(0.3)
    driver.find_element(By.LINK_TEXT, "Cerrar Sesión").click()
    time.sleep(0.3)
    driver.find_element(By.CSS_SELECTOR, ".swal2-confirm").click()
    time.sleep(0.3)
    driver.find_element(By.NAME, "username_email").clear()
    time.sleep(0.3)
    driver.find_element(By.NAME, "password").clear()

    driver.quit()