from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

edge_driver_path = 'C:/Users/msi/Documents/Selenium/msedgedriver.exe'
driver = webdriver.Edge(executable_path=edge_driver_path)

driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')

driver.set_window_size(981, 816)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
time.sleep(0.3)
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").click()
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@gmail.com")
driver.find_element(By.NAME, "login").click()
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
time.sleep(0.3)
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
time.sleep(0.3)
driver.find_element(By.NAME, "password").click()
driver.find_element(By.NAME, "password").click()
element = driver.find_element(By.NAME, "password")
time.sleep(0.3)
actions = ActionChains(driver)
actions.double_click(element).perform()
driver.find_element(By.CSS_SELECTOR, ".col-12").click()
driver.find_element(By.NAME, "username_email").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".col-12").click()
driver.find_element(By.NAME, "username_email").click()
driver.find_element(By.NAME, "username_email").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".col-12").click()
driver.find_element(By.LINK_TEXT, "¿Olvidaste tu Contraseña?").click()
driver.find_element(By.NAME, "email").click()
driver.find_element(By.NAME, "email").clear()
time.sleep(0.3)
driver.find_element(By.NAME, "email").send_keys("pepito@est.una.ac.cr")
driver.find_element(By.NAME, "forgotSubmit").click()
driver.find_element(By.NAME, "forgotSubmit").click()
time.sleep(0.3)
driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')
driver.find_element(By.CSS_SELECTOR, ".regisFrm").click()
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
driver.find_element(By.NAME, "login").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".bg-image").click()
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "li:nth-child(6) span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".swal2-confirm").click()
driver.find_element(By.CSS_SELECTOR, ".section").click()
driver.quit()