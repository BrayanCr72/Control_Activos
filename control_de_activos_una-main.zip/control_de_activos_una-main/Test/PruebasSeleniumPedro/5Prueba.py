from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import json
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

edge_driver_path = 'C:/Users/msi/Documents/Selenium/msedgedriver.exe'
driver = webdriver.Edge(executable_path=edge_driver_path)

driver.get('http://localhost/control_de_activos_una/development/Backend/view/login.php')

driver.set_window_size(1500, 800)
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "username_email").send_keys("pepito@est.una.ac.cr")
driver.find_element(By.NAME, "password").clear()
driver.find_element(By.NAME, "password").send_keys("12345678")
driver.find_element(By.NAME, "login").click()
time.sleep(1)
driver.find_element(By.CSS_SELECTOR, ".badge-number").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".notification-item:nth-child(7) p:nth-child(2)").click()
driver.find_element(By.CSS_SELECTOR, ".badge-number").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".notification-item:nth-child(5) h4").click()
driver.find_element(By.CSS_SELECTOR, ".bi-bell").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".notification-item:nth-child(3) > div").click()
driver.find_element(By.CSS_SELECTOR, ".bi-bell").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".notification-item:nth-child(9) h4").click()
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "li:nth-child(3) > .dropdown-item > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#dark-mode-button > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#dark-mode-button > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#dark-mode-button > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#dark-mode-button > span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "#sidebar-nav > .nav-item:nth-child(1) span").click()
driver.find_element(By.ID, "sidebar").click()
time.sleep(0.3)
driver.find_element(By.ID, "sidebar-toggle-btn").click()
time.sleep(0.3)
driver.find_element(By.ID, "sidebar-toggle-btn").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".d-none").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, "li:nth-child(6) span").click()
time.sleep(0.3)
driver.find_element(By.CSS_SELECTOR, ".swal2-confirm").click()
time.sleep(0.3)
driver.find_element(By.NAME, "username_email").clear()
driver.find_element(By.NAME, "password").clear()

driver.quit()